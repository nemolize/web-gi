# Intermittent Adreno compute pipeline compilation crash

Standalone reproduction extracted from `nemolize/web-gi` revision
`a5aa13b39828e3cf6e6bd068b379b089880d04ac`. No build step or dependencies.
This is an isolated reproduction, not a minimal shader or a rendering fix.

## Run

1. In this directory, run `python3 -m http.server 8769 --bind 127.0.0.1`.
2. Connect the Android device using ADB (USB or already-paired wireless).
   Run `adb -s DEVICE_SERIAL reverse tcp:8769 tcp:8769`.
3. Open `http://localhost:8769/` in the target browser, choose a variant, press
   **Run once**, and retain the JSON report.
4. Reload to repeat. Record every trial; a single pass does not establish
   compatibility. If no adapter is available, restart the browser and label that
   trial separately from a compilation failure.
5. Remove the temporary forwarding when finished:
   `adb -s DEVICE_SERIAL reverse --remove tcp:8769`.

Keep the browser foreground while comparing trials. Serving via a LAN HTTP
address is not equivalent to localhost's secure context. No diagnostic browser
flags are required. `file://` is not supported by this fetch-based harness.
The page runs only on a button press and never uploads results.

The 30-second timeout covers shader and pipeline compilation after device
creation; it does not cover source loading or adapter/device acquisition.

### Capturing the native crash

The page only reports device loss. The driver crash itself is in the Android
crash buffer, so capture it alongside each trial:

```sh
start=$(adb -s DEVICE_SERIAL shell "date '+%m-%d %H:%M:%S.000'")
# press Run once, wait for the report, then:
adb -s DEVICE_SERIAL logcat -d -b crash -v threadtime -T "$start" \
  | grep -E 'Cmdline: |Fatal signal|signal 11|#00 pc|vkCreateComputePipelines'
```

Taking `start` from the device clock rather than the host clock is what makes
the excerpt line up with the trial. The `crash` arrays in `validation.jsonl`
are the output of exactly this filter.

## What it does

Requests a high-performance adapter and a default device, validates the selected
WGSL, then calls `createComputePipelineAsync`. Uses explicit bind-group layouts,
entry point `main`, and override `BDPT_WORKGROUP_SIZE = 1`. All four WGSL files
have a vertex capacity of 10. No buffers, bind groups, render commands, or
dispatches are created. The device is destroyed afterward. See `SHA256SUMS` for
integrity.

## The four variants, and what separates them

All four are exact captures, and all four descend from the same production
shader `src/gi/shaders/bdpt-spatial.wgsl` at the revision above. They are **not**
a single shader plus or minus one construct, so no pair of them isolates one
language feature. The table gives the derivation:

| File | Forward replay | Inverse replay | Neighbor domains | Write-back |
| --- | --- | --- | --- | --- |
| `control.wgsl` | removed | removed | production discovery loop | production reservoir |
| `two-neighbors.wgsl` | removed | kept | production discovery loop | production reservoir |
| `no-discovery.wgsl` | removed | kept | two synthetic neighbors | production reservoir |
| `repro.wgsl` | removed | kept | two synthetic neighbors | direct diagnostic output |

Each row differs from the row above it in exactly one column, so consecutive
rows are one-axis comparisons. `control.wgsl` and `repro.wgsl` differ in three
columns at once; a comparison between only those two cannot attribute the crash
to any single one of them.

The production discovery loop performs up to 32 iterations and calls
`traceScenePrimary` per iteration, so removing it makes the shader smaller, not
larger. The diagnostic write-back drops the reservoir update and stores the
shift result directly.

## Observations

Device: Samsung SM-F966Q, Android 16, Adreno 830.
Mises package: `site.mises.browser_stable`. Its CDP version reported
Chrome/141.0.7390.108; the page UA reports Chrome/140.0.0.0. Chrome CDP reported
Chrome/153.0.8010.52. `environment.json` records selected ADB properties and CDP
version fields. `validation.jsonl` holds every trial with its browser state.

### Chrome 153, 2026-09-23

Each group below ran in a freshly restarted browser, foreground throughout.

| Variant | Result | Native crash |
| --- | --- | --- |
| `repro` | 0 pass / 3 trials | 3 |
| `two-neighbors` | 0 pass / 4 trials | 4 |
| `no-discovery` | 4 pass / 4 trials | 0 |
| `control` | 4 pass / 4 trials | 0 |

Two results follow directly, and both contradict a one-construct reading:

- **The inverse replay is not sufficient.** `no-discovery.wgsl` contains it and
  passed every trial.
- **`two-neighbors.wgsl` crashes, and it is the variant closest to production**:
  it keeps the discovery loop and the reservoir write-back, and differs from the
  production shader only by the removal of the forward replay and a cap of two
  neighbor iterations.

`no-discovery` and `two-neighbors` are one column apart, and one crashes while
the other does not; `two-neighbors` and `repro` are two columns apart, and both
crash. No single column tracks the outcome.

One earlier `no-discovery` trial did fail, in a Chrome process that had already
crashed twice in the preceding minute and that returned `NO_ADAPTER` on the two
trials after it. It is retained in `validation.jsonl` with its browser state and
is excluded from the table above.

### Cache control

A pass may be a cache hit rather than a fresh compile. To force a distinct cache
key, append a blank line and one comment to a WGSL file, then serve the copy as
its own variant:

```sh
printf '\n// cache-key probe 1790088000\n' >> repro-probe.wgsl
```

`repro.wgsl` with that suffix appended (SHA-256
`194cdf0d78aad504d4dd50118d09beb39f1dc9cfa9db41df7ae10421b64f6319`) failed 3/3
on Chrome, and `no-discovery.wgsl` with the same suffix appended (SHA-256
`55bb30ba5e480fb84e10140d664a9ac4826854c9544b7a2dd3b153889076c9e5`) passed 3/3.
Neither text had been compiled on the device before. The Chrome results above
therefore do not rest on cached blobs. Nothing here controls the driver's own
internal caches.

### Mises, 2026-09-23

Mises did not reproduce the crash at all on this date: `repro` passed 4/4, and
`repro` with the fresh cache key above also passed 4/4, as did `two-neighbors`
(4/4). On 2026-09-22 the same `repro` shader failed 2 of 6 trials in the same
browser on the same device. The crash is therefore intermittent across sessions
in a way a single day's failure rate does not capture, and the 2026-09-22 Mises
figures should not be read as a rate.

### Native crash signature

Every failing trial across both browsers and all dates correlated with
SIGSEGV / SEGV_ACCERR in the browser's privileged process, with top frame
`/vendor/lib64/libllvm-qgl.so`, offset `0x5462dc`, BuildId
`cef5d401886c24314fb684ab4dd7e70a`. The stack includes
`qglinternal::vkCreateComputePipelines` in `vulkan.adreno.so`, BuildId
`1267f8e0425e6782225076cf3e39aa61`. The offset and BuildIds are identical for
`repro` and for `two-neighbors`.

This identifies a native compiler-path crash, not its precise root cause.
Generated SPIR-V was not obtained. Browser/Tint output differences, driver
compiler behavior, and resource pressure have not been separated. Identical
WGSL does not establish identical generated SPIR-V.

### Earlier trials, 2026-09-22

Sequences 1 through 13 in `validation.jsonl` are the original session, run with
only `repro` and `control` present and before the harness gained its
terminal-state guard (below). On that date Mises failed 2 of 6 `repro` trials
and Chrome failed 3 of 3. Earlier application-diagnostic passes in Chrome do not
establish that a browser version fixes this.

## Harness note

`run.js` stops shader validation and pipeline creation once the race has settled
on a timeout or device loss, so a late response cannot rewrite a finished report
or reach a destroyed device. Sequences 1 through 12 predate that guard;
sequence 13 onward include it. The guard does not touch compilation itself.
