// Shared constants, data layouts, RNG and sampling helpers.
// This file declares no bindings so it can be prepended to every shader,
// including the ones that never touch the scene buffers.

const PI: f32 = 3.14159265359;
const INV_PI: f32 = 0.31830988618;
const RAY_EPS: f32 = 1e-4;
const SURFACE_EPS: f32 = 1e-3;
const T_FAR: f32 = 1e20;
/** Firefly guard; generous enough that it never clips the lit floor. */
const MAX_ILLUMINATION: f32 = 200.0;
/** 64 was the radius' own maximum back when it was a pixel count (#90). */
const SPATIAL_MIN_PIXEL_RADIUS: f32 = 1.0;
const SPATIAL_MAX_PIXEL_RADIUS: f32 = 64.0;

/**
 * vec4f throughout: a `vec3f` followed by a scalar packs that scalar into the
 * vec3's padding word, and drivers disagree on the resulting offsets (an Adreno
 * device read `forward` as `up`). Byte layout matches the packed form, so the
 * CPU-side writer is unchanged.
 */
struct Camera {
  pos: vec4f,     // xyz = eye position, w = tanHalfFov
  right: vec4f,   // xyz = right axis,   w = aspect
  up: vec4f,      // xyz = up axis
  forward: vec4f, // xyz = forward axis
}

fn camTanHalfFov(cam: Camera) -> f32 {
  return cam.pos.w;
}

fn camAspect(cam: Camera) -> f32 {
  return cam.right.w;
}

struct Uniforms {
  cam: Camera,
  prevCam: Camera,
  resolution: vec2u,
  frame: u32,
  accumFrames: u32,
  quadCount: u32,
  lightCount: u32,
  diCandidates: u32,
  spatialSamples: u32,
  maxBounces: u32,
  maxHistory: u32,
  flags: u32,
  spatialRadius: f32,
  exposure: f32,
  clusterCount: u32,
  occluderClusterCount: u32,
  glassShapeCount: u32,
  atrousTangentSigma: f32,
  historyFrames: u32,
  previousResolution: vec2u,
  transition: vec4f,
}

/** vec4f throughout for the same reason as `Camera`; layout is unchanged. */
struct Quad {
  origin: vec4f,   // xyz = corner, w = area
  u: vec4f,        // xyz = first edge,  w = 1/|u|^2
  v: vec4f,        // xyz = second edge, w = 1/|v|^2
  normal: vec4f,   // xyz = unit normal
  albedo: vec4f,   // xyz = diffuse albedo
  emission: vec4f, // xyz = emitted radiance
}

struct GlassShape {
  centerKind: vec4f, // xyz = centre, w = 0 sphere / 1 box
  extentRadius: vec4f, // xyz = box half extents, w = sphere radius
  tintIor: vec4f, // xyz = transmission tint, w = index of refraction
}

struct Light {
  quadIndex: u32,
  cdf: f32,
  selectPdf: f32,
  _pad0: f32,
}

/**
 * Bound around a run of occluder quads. Counts ride in the w lanes for the
 * same portability reason as `Camera`; they are small integers, so f32 is exact.
 */
struct Cluster {
  lo: vec4f, // xyz = min corner, w = index of the first quad
  hi: vec4f, // xyz = max corner, w = number of quads
}

// Direct-lighting reservoir. The chosen sample is a point on an emissive quad;
// its normal and radiance are re-read from `quads[lightQuad]` on demand rather
// than stored, which keeps the per-pixel footprint at 32 bytes.
struct DiReservoir {
  lightPos: vec4f, // xyz = point on the emissive quad
  lightQuad: u32,
  wSum: f32,
  m: f32,
  targetPdf: f32,
}

// Indirect-lighting reservoir. The sample is a surface point with the outgoing
// radiance it carries towards the visible point that generated it. Scalars ride
// in the w lanes for the same portability reason as `Camera`; still 48 bytes.
struct GiReservoir {
  samplePos: vec4f,    // xyz = sample point,  w = m
  sampleNormal: vec4f, // xyz = sample normal, w = wSum
  radiance: vec4f,     // xyz = outgoing radiance, w = targetPdf
}

fn giM(r: GiReservoir) -> f32 {
  return r.samplePos.w;
}

fn giWSum(r: GiReservoir) -> f32 {
  return r.sampleNormal.w;
}

fn giTarget(r: GiReservoir) -> f32 {
  return r.radiance.w;
}

// Writes go through these too: with the lane mapping hardcoded at each write
// site, reshuffling the lanes would update the readers and silently corrupt
// the writers.
fn giSetM(r: ptr<function, GiReservoir>, value: f32) {
  (*r).samplePos.w = value;
}

fn giAddM(r: ptr<function, GiReservoir>, inc: f32) {
  (*r).samplePos.w += inc;
}

fn giSetWSum(r: ptr<function, GiReservoir>, value: f32) {
  (*r).sampleNormal.w = value;
}

fn giAddWSum(r: ptr<function, GiReservoir>, inc: f32) {
  (*r).sampleNormal.w += inc;
}

/** Replaces the stored sample, preserving the running m and wSum. */
fn giSetSample(
  r: ptr<function, GiReservoir>,
  samplePos: vec3f,
  sampleNormal: vec3f,
  radiance: vec3f,
  targetPdf: f32,
) {
  (*r).samplePos = vec4f(samplePos, giM(*r));
  (*r).sampleNormal = vec4f(sampleNormal, giWSum(*r));
  (*r).radiance = vec4f(radiance, targetPdf);
}

/** A single-sample reservoir with m and wSum still zero. */
fn giReservoirSample(
  samplePos: vec3f,
  sampleNormal: vec3f,
  radiance: vec3f,
) -> GiReservoir {
  return GiReservoir(
    vec4f(samplePos, 0.0),
    vec4f(sampleNormal, 0.0),
    vec4f(radiance, 0.0),
  );
}

const FLAG_DI_ENABLED: u32 = 1u;
const FLAG_DI_TEMPORAL: u32 = 2u;
const FLAG_DI_SPATIAL: u32 = 4u;
const FLAG_GI_ENABLED: u32 = 8u;
const FLAG_GI_TEMPORAL: u32 = 16u;
const FLAG_GI_SPATIAL: u32 = 32u;
const FLAG_DENOISE: u32 = 64u;
const FLAG_PT_FALLBACK: u32 = 128u;
const FLAG_BDPT: u32 = 256u;

// ---------------------------------------------------------------- RNG

var<private> gRngState: u32;

fn pcgNext() -> u32 {
  gRngState = gRngState * 747796405u + 2891336453u;
  let word = ((gRngState >> ((gRngState >> 28u) + 4u)) ^ gRngState) * 277803737u;
  return (word >> 22u) ^ word;
}

fn rngInit(pixel: vec2u, frame: u32, salt: u32) {
  gRngState = pixel.x * 1973u + pixel.y * 9277u + frame * 26699u + salt * 6151u;
  gRngState = pcgNext();
  gRngState = pcgNext();
}

fn rand() -> f32 {
  return f32(pcgNext()) * 2.3283064365386963e-10;
}

fn rand2() -> vec2f {
  return vec2f(rand(), rand());
}

// ---------------------------------------------------------------- math

fn luminance(c: vec3f) -> f32 {
  return dot(c, vec3f(0.2126, 0.7152, 0.0722));
}

fn maxComponent(c: vec3f) -> f32 {
  return max(c.x, max(c.y, c.z));
}

fn safeDiv(a: f32, b: f32) -> f32 {
  return select(0.0, a / b, b > 0.0);
}

// Duff et al., "Building an Orthonormal Basis, Revisited".
fn onbFromNormal(n: vec3f) -> mat3x3f {
  let s = select(-1.0, 1.0, n.z >= 0.0);
  let a = -1.0 / (s + n.z);
  let b = n.x * n.y * a;
  return mat3x3f(
    vec3f(1.0 + s * n.x * n.x * a, s * b, -s * n.x),
    vec3f(b, s + n.y * n.y * a, -n.y),
    n,
  );
}

fn cosineSampleHemisphere(n: vec3f, u1: f32, u2: f32) -> vec3f {
  let r = sqrt(u1);
  let phi = 2.0 * PI * u2;
  let local = vec3f(r * cos(phi), r * sin(phi), sqrt(max(0.0, 1.0 - u1)));
  return normalize(onbFromNormal(n) * local);
}

/**
 * View ray through `ndc`, unnormalised so its forward component is exactly 1.
 * That is what makes the G-buffer's stored depth a plain view-space distance:
 * `pos = cam.pos + viewRay * depth`, with no renormalisation on either side.
 */
fn viewRay(cam: Camera, ndc: vec2f) -> vec3f {
  return cam.forward.xyz
    + cam.right.xyz * (ndc.x * camTanHalfFov(cam) * camAspect(cam))
    + cam.up.xyz * (ndc.y * camTanHalfFov(cam));
}

/** `ndc` is y-up in [-1, 1]. Mirrored by `primaryRayDirection` in camera.ts. */
fn primaryRayDir(cam: Camera, ndc: vec2f) -> vec3f {
  return normalize(viewRay(cam, ndc));
}

/** Centre of `pixel` in y-up normalised device coordinates. */
fn pixelNdc(pixel: vec2u) -> vec2f {
  let uv = (vec2f(pixel) + 0.5) / vec2f(uni.resolution);
  return vec2f(uv.x * 2.0 - 1.0, 1.0 - uv.y * 2.0);
}

/**
 * The G-buffer stores view-space depth rather than a world position: the `.w`
 * lane of an rgba32float only ever carried a hit flag, so three quarters of the
 * widest and most-read target were reconstructible all along. Depth is
 * `dot(pos - eye, forward)`, which the unit-forward `viewRay` inverts directly.
 */
fn surfaceDepth(cam: Camera, pos: vec3f) -> f32 {
  return dot(pos - cam.pos.xyz, cam.forward.xyz);
}

fn surfacePosition(cam: Camera, pixel: vec2u, depth: f32) -> vec3f {
  return cam.pos.xyz + viewRay(cam, pixelNdc(pixel)) * depth;
}

/** Zero means the primary ray escaped; every real hit is in front of the eye. */
fn surfaceHit(depth: f32) -> bool {
  return depth > 0.0;
}

/**
 * World distance spanned by one pixel of vertical offset at `depth`. Exact
 * rather than approximate: `viewRay` is linear in ndc and `depth` is measured
 * along `forward`, so the ratio does not vary across the frame.
 */
fn worldPerPixel(cam: Camera, depth: f32) -> f32 {
  return depth * 2.0 * camTanHalfFov(cam) / f32(uni.resolution.y);
}

/** Clamped because the conversion diverges as a surface nears the eye. */
fn spatialPixelRadius(cam: Camera, depth: f32) -> f32 {
  let perPixel = worldPerPixel(cam, depth);
  // Unreachable via `surfaceHit`; guards WGSL's indeterminate division rather
  // than a real input.
  if (perPixel <= 0.0) {
    return SPATIAL_MIN_PIXEL_RADIUS;
  }
  return clamp(
    uni.spatialRadius / perPixel,
    SPATIAL_MIN_PIXEL_RADIUS,
    SPATIAL_MAX_PIXEL_RADIUS,
  );
}

/**
 * Uniform over the disc of `pixelRadius`, floored at one pixel of offset so the
 * tap cannot land back on the centre pixel and merge the reservoir into itself.
 *
 * Rounds to nearest, not outward: outward lengthens every offset, and at a
 * grazing angle the guard accepts an ellipse only `pixelRadius * cos(incidence)`
 * pixels across, so the lengthening pushes most taps outside it.
 */
fn spatialOffset(pixelRadius: f32, angle: f32, u: f32) -> vec2i {
  let radius = max(pixelRadius * sqrt(u), SPATIAL_MIN_PIXEL_RADIUS);
  let direction = vec2f(cos(angle), sin(angle));
  return vec2i(round(direction * radius));
}

/** Returns top-left-origin screen UV in xy; z is 1 when the point is on screen. */
fn projectToUv(cam: Camera, p: vec3f) -> vec3f {
  let d = p - cam.pos.xyz;
  let z = dot(d, cam.forward.xyz);
  if (z <= 1e-4) {
    return vec3f(0.0, 0.0, 0.0);
  }
  let x = dot(d, cam.right.xyz) / (z * camTanHalfFov(cam) * camAspect(cam));
  let y = dot(d, cam.up.xyz) / (z * camTanHalfFov(cam));
  let onScreen = select(0.0, 1.0, abs(x) <= 1.0 && abs(y) <= 1.0);
  return vec3f(x * 0.5 + 0.5, 0.5 - y * 0.5, onScreen);
}

/**
 * Pixel coordinates as one u32, for the spatial passes' dynamically-indexed
 * neighbour lists. 16 bits per axis covers any resolution the renderer can
 * allocate, and halves an array that lives in per-thread scratch.
 */
fn packPixel(pixel: vec2u) -> u32 {
  return (pixel.y << 16u) | (pixel.x & 0xffffu);
}

fn unpackPixel(packed: u32) -> vec2u {
  return vec2u(packed & 0xffffu, packed >> 16u);
}

// ---------------------------------------------------------------- reservoirs

fn diReservoirEmpty() -> DiReservoir {
  return DiReservoir(vec4f(0.0), 0u, 0.0, 0.0, 0.0);
}

/** Weighted reservoir sampling: fold one candidate of weight `w` into `r`. */
fn diReservoirUpdate(
  r: ptr<function, DiReservoir>,
  lightPos: vec3f,
  lightQuad: u32,
  w: f32,
  targetPdf: f32,
  mInc: f32,
  u: f32,
) {
  (*r).m += mInc;
  if (w <= 0.0) {
    return;
  }
  (*r).wSum += w;
  if (u * (*r).wSum <= w) {
    (*r).lightPos = vec4f(lightPos, 0.0);
    (*r).lightQuad = lightQuad;
    (*r).targetPdf = targetPdf;
  }
}

/** Unbiased contribution weight of the surviving sample. */
fn diReservoirWeight(r: DiReservoir) -> f32 {
  return safeDiv(r.wSum, r.m * r.targetPdf);
}

/**
 * Bound the history length. `wSum` is scaled by the same factor because the
 * contribution weight is derived as `wSum / (M * targetPdf)`: capping `M`
 * alone inflates every reused weight, and the error compounds each frame until
 * the estimate diverges.
 */
fn diReservoirCapM(r: DiReservoir, cap: f32) -> DiReservoir {
  if (r.m <= cap || r.m <= 0.0) {
    return r;
  }
  var capped = r;
  capped.wSum = r.wSum * (cap / r.m);
  capped.m = cap;
  return capped;
}

fn giReservoirEmpty() -> GiReservoir {
  return GiReservoir(vec4f(0.0), vec4f(0.0, 1.0, 0.0, 0.0), vec4f(0.0));
}

fn giReservoirUpdate(
  r: ptr<function, GiReservoir>,
  samplePos: vec3f,
  sampleNormal: vec3f,
  radiance: vec3f,
  w: f32,
  targetPdf: f32,
  mInc: f32,
  u: f32,
) {
  giAddM(r, mInc);
  if (w <= 0.0) {
    return;
  }
  giAddWSum(r, w);
  if (u * giWSum(*r) <= w) {
    giSetSample(r, samplePos, sampleNormal, radiance, targetPdf);
  }
}

fn giReservoirWeight(r: GiReservoir) -> f32 {
  return safeDiv(giWSum(r), giM(r) * giTarget(r));
}

/** See `diReservoirCapM`. */
fn giReservoirCapM(r: GiReservoir, cap: f32) -> GiReservoir {
  if (giM(r) <= cap || giM(r) <= 0.0) {
    return r;
  }
  var capped = r;
  giSetWSum(&capped, giWSum(r) * (cap / giM(r)));
  giSetM(&capped, cap);
  return capped;
}

// ---------------------------------------------------------------- display

fn acesFilmic(x: vec3f) -> vec3f {
  let a = 2.51;
  let b = 0.03;
  let c = 2.43;
  let d = 0.59;
  let e = 0.14;
  return clamp((x * (a * x + b)) / (x * (c * x + d) + e), vec3f(0.0), vec3f(1.0));
}

fn linearToSrgb(c: vec3f) -> vec3f {
  let lo = c * 12.92;
  let hi = 1.055 * pow(max(c, vec3f(0.0)), vec3f(1.0 / 2.4)) - 0.055;
  return select(hi, lo, c <= vec3f(0.0031308));
}

// Scene bindings and the ray-tracing / light-sampling kernel shared by every
// compute pass. Group 0 is identical for all of them so a single explicit bind
// group layout can be reused.

@group(0) @binding(0) var<uniform> uni: Uniforms;
@group(0) @binding(1) var<storage, read> quads: array<Quad>;
@group(0) @binding(2) var<storage, read> lights: array<Light>;
@group(0) @binding(3) var<storage, read> clusters: array<Cluster>;
@group(0) @binding(4) var<storage, read> glassShapes: array<GlassShape>;

struct HitInfo {
  hit: bool,
  t: f32,
  pos: vec3f,
  normal: vec3f,
  albedo: vec3f,
  emission: vec3f,
  quadIndex: u32,
  materialIndex: u32,
  frontFace: bool,
}

/**
 * Ray/parallelogram intersection. Quad edges are perpendicular by construction
 * (see `makeQuad`), so the barycentric solve is two independent projections.
 *
 * Takes the index rather than the quad so each field is read only once the
 * preceding test has passed: a miss never touches `albedo` or `emission`.
 */
fn intersectQuad(index: u32, ro: vec3f, rd: vec3f, tMax: f32) -> f32 {
  let normal = quads[index].normal.xyz;
  let denom = dot(normal, rd);
  if (abs(denom) < 1e-9) {
    return -1.0;
  }
  let origin = quads[index].origin.xyz;
  let t = dot(normal, origin - ro) / denom;
  if (t <= RAY_EPS || t >= tMax) {
    return -1.0;
  }
  // `u.w` / `v.w` carry 1/|u|^2 and 1/|v|^2 from `packQuads`: recomputing them
  // here costs two dots and two divides on every quad of every ray.
  let p = ro + rd * t - origin;
  let u = quads[index].u;
  let a = dot(p, u.xyz) * u.w;
  if (a < 0.0 || a > 1.0) {
    return -1.0;
  }
  let v = quads[index].v;
  let b = dot(p, v.xyz) * v.w;
  if (b < 0.0 || b > 1.0) {
    return -1.0;
  }
  return t;
}

fn intersectSphere(index: u32, ro: vec3f, rd: vec3f, tMax: f32) -> f32 {
  let shape = glassShapes[index];
  let offset = ro - shape.centerKind.xyz;
  let halfB = dot(offset, rd);
  let c = dot(offset, offset) - shape.extentRadius.w * shape.extentRadius.w;
  let discriminant = halfB * halfB - c;
  if (discriminant < 0.0) {
    return -1.0;
  }
  let root = sqrt(discriminant);
  let near = -halfB - root;
  if (near > RAY_EPS && near < tMax) {
    return near;
  }
  let far = -halfB + root;
  return select(-1.0, far, far > RAY_EPS && far < tMax);
}

fn intersectBox(index: u32, ro: vec3f, rd: vec3f, tMax: f32) -> f32 {
  let shape = glassShapes[index];
  let lo = shape.centerKind.xyz - shape.extentRadius.xyz;
  let hi = shape.centerKind.xyz + shape.extentRadius.xyz;
  let inverseDirection = vec3f(safeInverse(rd.x), safeInverse(rd.y), safeInverse(rd.z));
  let a = (lo - ro) * inverseDirection;
  let b = (hi - ro) * inverseDirection;
  let near = min(a, b);
  let far = max(a, b);
  let enter = max(max(near.x, near.y), near.z);
  let exit = min(min(far.x, far.y), far.z);
  if (enter > exit) {
    return -1.0;
  }
  let t = select(exit, enter, enter > RAY_EPS);
  return select(-1.0, t, t > RAY_EPS && t < tMax);
}

fn intersectGlassShape(index: u32, ro: vec3f, rd: vec3f, tMax: f32) -> f32 {
  if (glassShapes[index].centerKind.w > 0.5) {
    return intersectBox(index, ro, rd, tMax);
  }
  return intersectSphere(index, ro, rd, tMax);
}

fn boxOutwardNormal(shape: GlassShape, position: vec3f) -> vec3f {
  let local = (position - shape.centerKind.xyz) / shape.extentRadius.xyz;
  let magnitude = abs(local);
  if (magnitude.x >= magnitude.y && magnitude.x >= magnitude.z) {
    return vec3f(sign(local.x), 0.0, 0.0);
  }
  if (magnitude.y >= magnitude.z) {
    return vec3f(0.0, sign(local.y), 0.0);
  }
  return vec3f(0.0, 0.0, sign(local.z));
}

fn resolveHitSurface(hit: HitInfo, ro: vec3f, rd: vec3f) -> HitInfo {
  var resolved = hit;
  resolved.pos = ro + rd * resolved.t;
  if (resolved.materialIndex == 0u) {
    let q = quads[resolved.quadIndex];
    resolved.normal = select(q.normal.xyz, -q.normal.xyz, dot(q.normal.xyz, rd) > 0.0);
    resolved.albedo = q.albedo.xyz;
    resolved.emission = q.emission.xyz;
    resolved.frontFace = dot(q.normal.xyz, rd) <= 0.0;
    return resolved;
  }
  let shape = glassShapes[resolved.materialIndex - 1u];
  var outwardNormal = normalize(resolved.pos - shape.centerKind.xyz);
  if (shape.centerKind.w > 0.5) {
    outwardNormal = boxOutwardNormal(shape, resolved.pos);
  }
  resolved.frontFace = dot(outwardNormal, rd) < 0.0;
  resolved.normal = select(-outwardNormal, outwardNormal, resolved.frontFace);
  resolved.albedo = shape.tintIor.xyz;
  resolved.emission = vec3f(0.0);
  return resolved;
}

fn materialAlbedo(materialIndex: u32) -> vec3f {
  if (materialIndex == 0u) {
    return vec3f(1.0);
  }
  return glassShapes[materialIndex - 1u].tintIor.xyz;
}

/**
 * Reciprocal that stays finite: the slab test multiplies by it, and an infinity
 * meeting a zero-length extent would produce a NaN that swallows the comparison.
 * The substituted magnitude is far beyond any t the scene can produce.
 */
fn safeInverse(v: f32) -> f32 {
  if (abs(v) < 1e-30) {
    return select(1e30, -1e30, v < 0.0);
  }
  return 1.0 / v;
}

/** Whether the segment `[RAY_EPS, tMax]` along `rd` can meet the box at all. */
fn segmentHitsBounds(lo: vec3f, hi: vec3f, ro: vec3f, invRd: vec3f, tMax: f32) -> bool {
  let a = (lo - ro) * invRd;
  let b = (hi - ro) * invRd;
  let near = min(a, b);
  let far = max(a, b);
  let enter = max(max(near.x, near.y), max(near.z, RAY_EPS));
  let exit = min(min(far.x, far.y), min(far.z, tMax));
  return enter <= exit;
}

/**
 * Closest hit, cluster by cluster. The traversal loop touches only the four
 * intersection fields; shading data is fetched once for the winner. Reading the
 * whole `Quad` per step instead keeps albedo and emission live across the loop,
 * and every ray pays that bandwidth on every quad it misses.
 */
fn traceScene(ro: vec3f, rd: vec3f) -> HitInfo {
  var best: HitInfo;
  best.hit = false;
  best.t = T_FAR;
  best.quadIndex = 0u;
  best.materialIndex = 0u;
  let invRd = vec3f(safeInverse(rd.x), safeInverse(rd.y), safeInverse(rd.z));
  // Walked back to front: the walls are the last cluster and a closest-hit ray
  // almost always reaches one, so taking them first gives `best.t` a real bound
  // immediately, and the block clusters ahead of them are then rejected by the
  // slab test instead of being intersected quad by quad.
  for (var c = uni.clusterCount; c > 0u; c = c - 1u) {
    let cluster = clusters[c - 1u];
    // `best.t` tightens as the walk proceeds, so a cluster already behind the
    // closest hit is rejected here too, not just one the ray line misses.
    if (!segmentHitsBounds(cluster.lo.xyz, cluster.hi.xyz, ro, invRd, best.t)) {
      continue;
    }
    let start = u32(cluster.lo.w);
    let end = start + u32(cluster.hi.w);
    for (var i = start; i < end; i = i + 1u) {
      let t = intersectQuad(i, ro, rd, best.t);
      if (t > 0.0) {
        best.hit = true;
        best.t = t;
        best.quadIndex = i;
        best.materialIndex = 0u;
      }
    }
  }
  for (var i = 0u; i < uni.glassShapeCount; i = i + 1u) {
    let t = intersectGlassShape(i, ro, rd, best.t);
    if (t > 0.0) {
      best.hit = true;
      best.t = t;
      best.materialIndex = i + 1u;
    }
  }
  if (best.hit) {
    return resolveHitSurface(best, ro, rd);
  }
  best.pos = ro + rd * best.t;
  return best;
}

/**
 * Primary-ray variant with back-face culling. The room is closed, so without
 * it the near wall would hide the interior; culling turns the eye-side wall
 * into a cutaway while secondary rays still bounce off it. Blocks are convex,
 * so culling their back faces changes nothing.
 */
fn traceScenePrimary(ro: vec3f, rd: vec3f) -> HitInfo {
  var best: HitInfo;
  best.hit = false;
  best.t = T_FAR;
  best.quadIndex = 0u;
  best.materialIndex = 0u;
  let invRd = vec3f(safeInverse(rd.x), safeInverse(rd.y), safeInverse(rd.z));
  // Back to front, for the same reason as `traceScene`.
  for (var c = uni.clusterCount; c > 0u; c = c - 1u) {
    let cluster = clusters[c - 1u];
    if (!segmentHitsBounds(cluster.lo.xyz, cluster.hi.xyz, ro, invRd, best.t)) {
      continue;
    }
    let start = u32(cluster.lo.w);
    let end = start + u32(cluster.hi.w);
    for (var i = start; i < end; i = i + 1u) {
      if (dot(quads[i].normal.xyz, rd) > 0.0) {
        continue;
      }
      let t = intersectQuad(i, ro, rd, best.t);
      if (t > 0.0) {
        best.hit = true;
        best.t = t;
        best.quadIndex = i;
        best.materialIndex = 0u;
      }
    }
  }
  for (var i = 0u; i < uni.glassShapeCount; i = i + 1u) {
    let t = intersectGlassShape(i, ro, rd, best.t);
    if (t > 0.0) {
      best.hit = true;
      best.t = t;
      best.materialIndex = i + 1u;
    }
  }
  if (best.hit) {
    return resolveHitSurface(best, ro, rd);
  }
  best.pos = ro + rd * best.t;
  return best;
}

/**
 * Segment occlusion between two points on the scene's interior surfaces. The
 * room is convex, so a segment with both ends inside it never reaches a wall —
 * and the walls are the last cluster, so stopping at `occluderClusterCount`
 * drops them. A straight connection through a dielectric is not a valid shadow
 * path, so glass shapes still block here; their transmitted light comes from
 * BSDF sampling instead. Closest-hit traversal walks every primitive.
 */
fn traceOccluded(ro: vec3f, rd: vec3f, tMax: f32) -> bool {
  let invRd = vec3f(safeInverse(rd.x), safeInverse(rd.y), safeInverse(rd.z));
  for (var c = 0u; c < uni.occluderClusterCount; c = c + 1u) {
    let cluster = clusters[c];
    if (!segmentHitsBounds(cluster.lo.xyz, cluster.hi.xyz, ro, invRd, tMax)) {
      continue;
    }
    let start = u32(cluster.lo.w);
    let end = start + u32(cluster.hi.w);
    for (var i = start; i < end; i = i + 1u) {
      if (intersectQuad(i, ro, rd, tMax) > 0.0) {
        return true;
      }
    }
  }
  for (var i = 0u; i < uni.glassShapeCount; i = i + 1u) {
    if (intersectGlassShape(i, ro, rd, tMax) > 0.0) {
      return true;
    }
  }
  return false;
}

/** True when nothing blocks the segment between two surface points. */
fn mutuallyVisible(origin: vec3f, originNormal: vec3f, destination: vec3f) -> bool {
  let d = destination - origin;
  let dist = length(d);
  if (dist < 1e-5) {
    return true;
  }
  let dir = d / dist;
  return !traceOccluded(origin + originNormal * SURFACE_EPS, dir, dist - 2.0 * SURFACE_EPS);
}

// ---------------------------------------------------------------- lights

struct LightSample {
  pos: vec3f,
  normal: vec3f,
  emission: vec3f,
  pdfArea: f32,
  quadIndex: u32,
}

/**
 * First light whose inclusive CDF exceeds `u`, by binary search — the CDF is
 * non-decreasing, so this picks exactly what a scan from the front would. The
 * grid variant has thirty emitters and every next-event estimate calls this,
 * which made the scan's average depth the cost that mattered.
 */
fn pickLight(u: f32) -> u32 {
  var lo = 0u;
  var hi = uni.lightCount - 1u;
  while (lo < hi) {
    let mid = (lo + hi) / 2u;
    if (u < lights[mid].cdf) {
      hi = mid;
    } else {
      lo = mid + 1u;
    }
  }
  return lo;
}

fn sampleLight(u0: f32, u1: f32, u2: f32) -> LightSample {
  var s: LightSample;
  let light = lights[pickLight(u0)];
  let q = quads[light.quadIndex];
  s.pos = q.origin.xyz + q.u.xyz * u1 + q.v.xyz * u2;
  s.normal = q.normal.xyz;
  s.emission = q.emission.xyz;
  s.quadIndex = light.quadIndex;
  s.pdfArea = safeDiv(light.selectPdf, q.origin.w);
  return s;
}

/**
 * Unshadowed reflected radiance from a point on an emissive quad. Passing
 * `albedo = vec3f(1)` yields the albedo-demodulated form the shading pass
 * stores for the denoiser.
 */
fn directContribution(
  x: vec3f,
  n: vec3f,
  albedo: vec3f,
  lightPos: vec3f,
  lightQuad: u32,
) -> vec3f {
  let q = quads[lightQuad];
  let d = lightPos - x;
  let dist2 = max(dot(d, d), 1e-9);
  let wi = d * inverseSqrt(dist2);
  let cosX = dot(n, wi);
  let cosL = dot(q.normal.xyz, -wi);
  if (cosX <= 0.0 || cosL <= 0.0) {
    return vec3f(0.0);
  }
  return albedo * INV_PI * q.emission.xyz * (cosX * cosL / dist2);
}

/** RIS target function for direct lighting: visibility is deferred to shading. */
fn diTargetPdf(x: vec3f, n: vec3f, albedo: vec3f, lightPos: vec3f, lightQuad: u32) -> f32 {
  return luminance(directContribution(x, n, albedo, lightPos, lightQuad));
}

/**
 * Whether `diTargetPdf` would be positive, without evaluating it. The 1/Z loops
 * only ask which contributors could have produced the surviving sample, and
 * everything the full form adds on top of the two cosines — the inverse square
 * root, the distance, `INV_PI` — is a strictly positive factor that cannot
 * change the answer. The unnormalised `d` therefore settles both signs.
 */
fn diSupported(x: vec3f, n: vec3f, albedo: vec3f, lightPos: vec3f, lightQuad: u32) -> bool {
  let q = quads[lightQuad];
  let d = lightPos - x;
  return dot(n, d) > 0.0
    && dot(q.normal.xyz, -d) > 0.0
    && luminance(albedo * q.emission.xyz) > 0.0;
}

/** Reflected radiance towards the visible point for a stored GI sample. */
fn giContribution(x: vec3f, n: vec3f, albedo: vec3f, r: GiReservoir) -> vec3f {
  let d = r.samplePos.xyz - x;
  let dist2 = max(dot(d, d), 1e-9);
  let wi = d * inverseSqrt(dist2);
  let cosX = dot(n, wi);
  let cosY = dot(r.sampleNormal.xyz, -wi);
  if (cosX <= 0.0 || cosY <= 0.0) {
    return vec3f(0.0);
  }
  return albedo * INV_PI * r.radiance.xyz * cosX;
}

fn giTargetPdf(x: vec3f, n: vec3f, albedo: vec3f, r: GiReservoir) -> f32 {
  return luminance(giContribution(x, n, albedo, r));
}

/** See `diSupported`; the same reduction, for a stored GI sample. */
fn giSupported(x: vec3f, n: vec3f, albedo: vec3f, r: GiReservoir) -> bool {
  let d = r.samplePos.xyz - x;
  return dot(n, d) > 0.0
    && dot(r.sampleNormal.xyz, -d) > 0.0
    && luminance(albedo * r.radiance.xyz) > 0.0;
}

/** Widest measure change a reused sample may carry before it is rejected. */
const MAX_RECONNECTION_JACOBIAN: f32 = 10.0;

/**
 * Reconnection Jacobian for moving a stored sample point from the visible
 * point `fromX` to `toX`: the solid-angle measure at the shading point changes
 * while the sample stays put. Returns 0 for a shift too distorted to reuse —
 * the ratio diverges where `toX` nearly touches the sample, so clamping instead
 * of rejecting would admit that sample at the clamp factor and blow out every
 * concave contact region.
 */
fn reconnectionJacobian(fromX: vec3f, toX: vec3f, samplePos: vec3f, sampleNormal: vec3f) -> f32 {
  let dFrom = fromX - samplePos;
  let dTo = toX - samplePos;
  let d2From = max(dot(dFrom, dFrom), 1e-9);
  let d2To = max(dot(dTo, dTo), 1e-9);
  let cosFrom = abs(dot(sampleNormal, dFrom * inverseSqrt(d2From)));
  let cosTo = abs(dot(sampleNormal, dTo * inverseSqrt(d2To)));
  if (cosFrom <= 1e-6) {
    return 0.0;
  }
  let jacobian = (cosTo * d2From) / (cosFrom * d2To);
  if (jacobian < 1.0 / MAX_RECONNECTION_JACOBIAN || jacobian > MAX_RECONNECTION_JACOBIAN) {
    return 0.0;
  }
  return jacobian;
}

// ---------------------------------------------------------------- path tracing

/** One next-event-estimation sample of direct lighting at a surface point. */
fn nextEventEstimation(pos: vec3f, n: vec3f, albedo: vec3f) -> vec3f {
  if (uni.lightCount == 0u) {
    return vec3f(0.0);
  }
  let ls = sampleLight(rand(), rand(), rand());
  if (ls.pdfArea <= 0.0) {
    return vec3f(0.0);
  }
  let d = ls.pos - pos;
  let dist2 = max(dot(d, d), 1e-9);
  let dist = sqrt(dist2);
  let wi = d / dist;
  let cosX = dot(n, wi);
  let cosL = dot(ls.normal, -wi);
  if (cosX <= 0.0 || cosL <= 0.0) {
    return vec3f(0.0);
  }
  if (traceOccluded(pos + n * SURFACE_EPS, wi, dist - 2.0 * SURFACE_EPS)) {
    return vec3f(0.0);
  }
  return albedo * INV_PI * ls.emission * (cosX * cosL / dist2) / ls.pdfArea;
}

fn fresnelReflectance(cosIncident: f32, eta: f32) -> f32 {
  let transmittedSinSquared = eta * eta * max(0.0, 1.0 - cosIncident * cosIncident);
  if (transmittedSinSquared >= 1.0) {
    return 1.0;
  }
  let cosTransmitted = sqrt(1.0 - transmittedSinSquared);
  let parallel = (cosIncident - eta * cosTransmitted) / (cosIncident + eta * cosTransmitted);
  let perpendicular = (eta * cosIncident - cosTransmitted) / (eta * cosIncident + cosTransmitted);
  return 0.5 * (parallel * parallel + perpendicular * perpendicular);
}

fn glassScatterDirection(
  incoming: vec3f,
  normal: vec3f,
  eta: f32,
  reflected: bool,
) -> vec3f {
  return select(refract(incoming, normal, eta), reflect(incoming, normal), reflected);
}

fn pathRadiance(
  startPos: vec3f,
  startNormal: vec3f,
  startAlbedo: vec3f,
  startMaterialIndex: u32,
  startFrontFace: bool,
  startIncoming: vec3f,
  maxBounces: u32,
) -> vec3f {
  var radiance = vec3f(0.0);
  var throughput = vec3f(1.0);
  var pos = startPos;
  var normal = startNormal;
  var albedo = startAlbedo;
  var materialIndex = startMaterialIndex;
  var frontFace = startFrontFace;
  var incoming = startIncoming;
  var diffuseBounces = 0u;
  let maxSteps = maxBounces + max(4u, uni.glassShapeCount * 4u);

  for (var step = 0u; step < maxSteps; step = step + 1u) {
    var dir = vec3f(0.0);
    let deltaScatter = materialIndex > 0u;
    if (deltaScatter) {
      let shape = glassShapes[materialIndex - 1u];
      let ior = shape.tintIor.w;
      let eta = select(ior, 1.0 / ior, frontFace);
      let cosTheta = min(dot(-incoming, normal), 1.0);
      let sinTheta = sqrt(max(0.0, 1.0 - cosTheta * cosTheta));
      let totalInternalReflection = eta * sinTheta > 1.0;
      let reflected = totalInternalReflection || rand() < fresnelReflectance(cosTheta, eta);
      dir = glassScatterDirection(incoming, normal, eta, reflected);
      if (!reflected) {
        throughput *= eta * eta;
        if (!frontFace) {
          throughput *= albedo;
        }
      }
    } else {
      radiance += throughput * nextEventEstimation(pos, normal, albedo);
      diffuseBounces += 1u;
      if (diffuseBounces >= maxBounces) {
        break;
      }
      throughput *= albedo;
      if (diffuseBounces >= 2u) {
        let survival = clamp(maxComponent(throughput), 0.05, 1.0);
        if (rand() > survival) {
          break;
        }
        throughput /= survival;
      }
      dir = cosineSampleHemisphere(normal, rand(), rand());
    }

    let hit = traceScene(pos + dir * SURFACE_EPS, dir);
    if (!hit.hit) {
      break;
    }
    if (deltaScatter && maxComponent(hit.emission) > 0.0) {
      radiance += throughput * hit.emission;
      break;
    }
    pos = hit.pos;
    normal = hit.normal;
    albedo = hit.albedo;
    materialIndex = hit.materialIndex;
    frontFace = hit.frontFace;
    incoming = dir;
  }
  return radiance;
}

struct BdptPathSample {
  techniqueSeeds: vec4u,
  contributionMis: vec4f,
}

struct BdptPathReservoir {
  sample: BdptPathSample,
  weightSum: f32,
  contributionWeight: f32,
  confidence: f32,
  targetDensity: f32,
}

struct BdptMisSum {
  maximum: f32,
  scaledSum: f32,
}

fn bdptTarget(sample: BdptPathSample) -> f32 {
  return dot(sample.contributionMis.xyz, vec3f(0.2126, 0.7152, 0.0722))
    * sample.contributionMis.w;
}

fn bdptInitialWeight(cameraVertices: u32, lightSubpathCount: u32) -> f32 {
  if (cameraVertices > 1u) {
    return 1.0;
  }
  if (lightSubpathCount == 0u) {
    return 0.0;
  }
  return 1.0 / f32(lightSubpathCount);
}

fn bdptEmptyReservoir(confidence: f32) -> BdptPathReservoir {
  var reservoir: BdptPathReservoir;
  reservoir.confidence = confidence;
  return reservoir;
}

fn bdptUpdateReservoir(
  reservoir: ptr<function, BdptPathReservoir>,
  sample: BdptPathSample,
  contributionWeight: f32,
  resamplingWeight: f32,
  forwardJacobian: f32,
  random: f32,
) -> bool {
  let targetDensity = bdptTarget(sample);
  let weight = targetDensity * contributionWeight * resamplingWeight * forwardJacobian;
  if (!(weight > 0.0) || weight > 3.402823e38) {
    return false;
  }
  (*reservoir).weightSum += weight;
  if (random * (*reservoir).weightSum < weight) {
    (*reservoir).sample = sample;
    (*reservoir).targetDensity = targetDensity;
    return true;
  }
  return false;
}

fn bdptFinalizeReservoir(reservoir: ptr<function, BdptPathReservoir>) {
  (*reservoir).contributionWeight = 0.0;
  if ((*reservoir).targetDensity > 0.0) {
    (*reservoir).contributionWeight = (*reservoir).weightSum / (*reservoir).targetDensity;
  }
}

fn bdptReservoirRadiance(reservoir: BdptPathReservoir) -> vec3f {
  return reservoir.sample.contributionMis.xyz
    * reservoir.sample.contributionMis.w * reservoir.contributionWeight;
}

fn bdptBalanceNumerator(confidence: f32, sourceTarget: f32, inverseJacobian: f32) -> f32 {
  return confidence * sourceTarget * inverseJacobian;
}

fn bdptPairwiseWeight(own: f32, other: f32) -> f32 {
  if (own <= 0.0) { return 0.0; }
  return own / (own + other);
}

fn bdptAccumulateMis(
  sum: ptr<function, BdptMisSum>,
  logRelativeDensity: f32,
  sampleCount: u32,
  supported: bool,
) {
  if (!supported || sampleCount == 0u) {
    return;
  }
  let score = 2.0 * (logRelativeDensity + log(f32(sampleCount)));
  if ((*sum).scaledSum == 0.0) {
    (*sum).maximum = score;
    (*sum).scaledSum = 1.0;
    return;
  }
  let maximum = max((*sum).maximum, score);
  (*sum).scaledSum = (*sum).scaledSum * exp((*sum).maximum - maximum)
    + exp(score - maximum);
  (*sum).maximum = maximum;
}

fn bdptMisWeight(sum: BdptMisSum, logRelativeDensity: f32, sampleCount: u32, supported: bool) -> f32 {
  if (!supported || sampleCount == 0u || sum.scaledSum == 0.0) {
    return 0.0;
  }
  return exp(2.0 * (logRelativeDensity + log(f32(sampleCount))) - sum.maximum)
    / sum.scaledSum;
}

struct BdptScatter {
  direction: vec3f,
  throughput: vec3f,
  forwardPdf: f32,
  reversePdf: f32,
  delta: bool,
}

fn bdptRandom() -> f32 {
  return f32(pcgNext() >> 8u) * (1.0 / 16777216.0);
}

fn bdptSampleScatter(hit: HitInfo, incoming: vec3f, radianceTransport: bool, random: vec3f) -> BdptScatter {
  var scatter: BdptScatter;
  let cosIncident = clamp(dot(-incoming, hit.normal), 0.0, 1.0);
  if (cosIncident <= 0.0) {
    return scatter;
  }
  if (hit.materialIndex == 0u) {
    scatter.direction = cosineSampleHemisphere(hit.normal, random.x, random.y);
    scatter.throughput = hit.albedo;
    scatter.forwardPdf = max(0.0, dot(scatter.direction, hit.normal)) * INV_PI;
    scatter.reversePdf = cosIncident * INV_PI;
    return scatter;
  }
  scatter.delta = true;
  let ior = glassShapes[hit.materialIndex - 1u].tintIor.w;
  let eta = select(ior, 1.0 / ior, hit.frontFace);
  let reflectance = fresnelReflectance(cosIncident, eta);
  if (random.z < reflectance || reflectance >= 1.0) {
    scatter.direction = reflect(incoming, hit.normal);
    scatter.throughput = vec3f(1.0);
    scatter.forwardPdf = reflectance;
    scatter.reversePdf = reflectance;
  } else {
    scatter.direction = refract(incoming, hit.normal, eta);
    scatter.throughput = vec3f(select(1.0, eta * eta, radianceTransport));
    // Reverse transport crosses the tint boundary on entry rather than exit.
    if (hit.frontFace != radianceTransport) {
      scatter.throughput *= hit.albedo;
    }
    scatter.forwardPdf = 1.0 - reflectance;
    scatter.reversePdf = 1.0 - reflectance;
  }
  return scatter;
}

fn bdptPdfToArea(pdfSolidAngle: f32, source: vec3f, destination: vec3f, destinationNormal: vec3f) -> f32 {
  let displacement = source - destination;
  let distanceSquared = dot(displacement, displacement);
  if (distanceSquared <= 0.0) {
    return 0.0;
  }
  let cosine = abs(dot(destinationNormal, displacement * inverseSqrt(distanceSquared)));
  return pdfSolidAngle * cosine / distanceSquared;
}

override BDPT_WORKGROUP_SIZE: u32 = 8u;

struct BdptDispatchRegion {
  origin: vec2u,
  extent: vec2u,
}

@group(2) @binding(0) var<uniform> bdptDispatchRegion: BdptDispatchRegion;

const BDPT_MAX_VERTICES: u32 = 10u;

struct BdptVertex {
  surface: HitInfo,
  incoming: vec3f,
  throughput: vec3f,
  sampledForwardPdf: f32,
  sampledReversePdf: f32,
  sampledDelta: bool,
}

struct BdptSubpath {
  vertices: array<BdptVertex, BDPT_MAX_VERTICES>,
  count: u32,
  emitterPdfArea: f32,
}

fn bdptExtendSubpath(path: ptr<function, BdptSubpath>, first: HitInfo, incoming: vec3f, throughput: vec3f, radianceTransport: bool, maximumVertices: u32, reconnection: vec4f, surfaceCode: u32) {
  var hit = first;
  var direction = incoming;
  var beta = throughput;
  var diffuseVertices = 0u;
  let limit = min(maximumVertices, BDPT_MAX_VERTICES);
  loop {
    if (!hit.hit || (*path).count >= limit) {
      break;
    }
    if (diffuseVertices >= uni.maxBounces + 1u
      && (!radianceTransport || hit.materialIndex > 0u || maxComponent(hit.emission) <= 0.0)) {
      break;
    }
    let index = (*path).count;
    (*path).count += 1u;
    (*path).vertices[index] = BdptVertex(hit, direction, beta, 0.0, 0.0, false);
    if (maxComponent(hit.emission) > 0.0 || (*path).count >= limit) {
      break;
    }
    diffuseVertices += select(1u, 0u, hit.materialIndex > 0u);
    let random = vec3f(bdptRandom(), bdptRandom(), bdptRandom());
    let scatter = bdptSampleScatter(hit, direction, radianceTransport, random);
    (*path).vertices[index].sampledForwardPdf = scatter.forwardPdf;
    (*path).vertices[index].sampledReversePdf = scatter.reversePdf;
    (*path).vertices[index].sampledDelta = scatter.delta;
    if (scatter.forwardPdf <= 0.0 || maxComponent(scatter.throughput) <= 0.0) {
      break;
    }
    beta *= scatter.throughput;
    direction = scatter.direction;
    if (reconnection.w > 0.0 && index + 2u == u32(reconnection.w)) {
      let difference = reconnection.xyz - hit.pos;
      if (hit.materialIndex > 0u || length(difference) <= SURFACE_EPS || dot(hit.normal, difference) <= 0.0) {
        (*path).count = 0u;
        return;
      }
      direction = normalize(difference);
      var connected = traceScene(hit.pos + direction * SURFACE_EPS, direction);
      if (!connected.hit || connected.materialIndex > 0u || length(connected.pos - reconnection.xyz) > 2.0 * SURFACE_EPS
        || connected.quadIndex != surfaceCode / 2u || connected.frontFace != ((surfaceCode & 1u) == 1u)) {
        (*path).count = 0u;
        return;
      }
      (*path).vertices[index].sampledForwardPdf = dot(hit.normal, direction) * INV_PI;
      connected.pos = reconnection.xyz;
      hit = connected;
      continue;
    }
    hit = traceScene(hit.pos + direction * SURFACE_EPS, direction);
  }
}

fn bdptBuildCameraSubpath(camera: Camera, ndc: vec2f, seed: u32, maximumSurfaces: u32, path: ptr<function, BdptSubpath>) {
  gRngState = seed;
  (*path).count = 0u;
  (*path).emitterPdfArea = 0.0;
  let direction = primaryRayDir(camera, ndc);
  let first = traceScenePrimary(camera.pos.xyz, direction);
  bdptExtendSubpath(path, first, direction, vec3f(1.0), true, maximumSurfaces, vec4f(0.0), 0u);
}

fn bdptBuildLightSubpath(seed: u32, maximumVertices: u32, path: ptr<function, BdptSubpath>) {
  gRngState = seed;
  (*path).count = 0u;
  (*path).emitterPdfArea = 0.0;
  if (uni.lightCount == 0u || maximumVertices == 0u) {
    return;
  }
  let light = sampleLight(bdptRandom(), bdptRandom(), bdptRandom());
  if (light.pdfArea <= 0.0) {
    return;
  }
  var emitter: HitInfo;
  emitter.hit = true;
  emitter.pos = light.pos;
  emitter.normal = light.normal;
  emitter.emission = light.emission;
  emitter.quadIndex = light.quadIndex;
  emitter.frontFace = true;
  (*path).count = 1u;
  (*path).emitterPdfArea = light.pdfArea;
  (*path).vertices[0] = BdptVertex(emitter, vec3f(0.0), light.emission / light.pdfArea, 0.0, 0.0, false);
  let direction = cosineSampleHemisphere(light.normal, bdptRandom(), bdptRandom());
  let directionPdf = max(0.0, dot(light.normal, direction)) * INV_PI;
  (*path).vertices[0].sampledForwardPdf = directionPdf;
  if (directionPdf <= 0.0 || maximumVertices == 1u) {
    return;
  }
  let first = traceScene(light.pos + direction * SURFACE_EPS, direction);
  bdptExtendSubpath(path, first, direction, light.emission * PI / light.pdfArea, false, maximumVertices, vec4f(0.0), 0u);
}

fn bdptCameraSubpath(camera: Camera, ndc: vec2f, seed: u32, maximumSurfaces: u32) -> BdptSubpath {
  var path: BdptSubpath;
  bdptBuildCameraSubpath(camera, ndc, seed, maximumSurfaces, &path);
  return path;
}

fn bdptLightSubpath(seed: u32, maximumVertices: u32) -> BdptSubpath {
  var path: BdptSubpath;
  bdptBuildLightSubpath(seed, maximumVertices, &path);
  return path;
}

fn bdptConnectSurfaces(cameraVertex: ptr<function, BdptVertex>, lightVertex: ptr<function, BdptVertex>, lightIsEmitter: bool) -> vec3f {
  let cameraHit = &(*cameraVertex).surface;
  let lightHit = &(*lightVertex).surface;
  if ((*cameraHit).materialIndex > 0u || (*lightHit).materialIndex > 0u) {
    return vec3f(0.0);
  }
  let difference = (*lightHit).pos - (*cameraHit).pos;
  let distanceSquared = dot(difference, difference);
  if (distanceSquared <= 0.0) {
    return vec3f(0.0);
  }
  let direction = difference * inverseSqrt(distanceSquared);
  let geometry = max(0.0, dot((*cameraHit).normal, direction))
    * max(0.0, dot((*lightHit).normal, -direction)) / distanceSquared;
  if (geometry <= 0.0 || !mutuallyVisible((*cameraHit).pos, (*cameraHit).normal, (*lightHit).pos)) {
    return vec3f(0.0);
  }
  let lightBsdf = select((*lightHit).albedo * INV_PI, vec3f(1.0), lightIsEmitter);
  return (*cameraVertex).throughput * (*cameraHit).albedo * INV_PI
    * (*lightVertex).throughput * lightBsdf * geometry;
}

fn bdptBuildCameraReplay(camera: Camera, ndc: vec2f, seed: u32, maximumSurfaces: u32, reconnection: vec4f, surfaceCode: u32, path: ptr<function, BdptSubpath>) {
  gRngState = seed;
  (*path).count = 0u;
  (*path).emitterPdfArea = 0.0;
  let direction = primaryRayDir(camera, ndc);
  bdptExtendSubpath(path, traceScenePrimary(camera.pos.xyz, direction), direction, vec3f(1.0), true, maximumSurfaces, reconnection, surfaceCode);
}

fn bdptCameraReconnection(path: ptr<function, BdptSubpath>) -> u32 {
  for (var index = 1u; index < (*path).count; index++) {
    if ((*path).vertices[index - 1u].surface.materialIndex == 0u && (*path).vertices[index].surface.materialIndex == 0u) {
      return index + 1u;
    }
  }
  return 0u;
}

fn bdptCameraConnectionPdf(path: ptr<function, BdptSubpath>, reconnection: u32) -> f32 {
  if (reconnection < 2u || reconnection > (*path).count) { return 0.0; }
  let source = (*path).vertices[reconnection - 2u].surface;
  let destination = (*path).vertices[reconnection - 1u].surface;
  let difference = destination.pos - source.pos;
  if (length(difference) <= SURFACE_EPS) { return 0.0; }
  return bdptPdfToArea(max(0.0, dot(source.normal, normalize(difference))) * INV_PI, source.pos, destination.pos, destination.normal);
}

struct BdptCameraConnection {
  pixel: vec2u,
  film: vec2f,
  pdfArea: f32,
  valid: bool,
}

fn bdptCameraPdfW(camera: Camera, direction: vec3f) -> f32 {
  let cosine = dot(camera.forward.xyz, direction);
  if (cosine <= 0.0) {
    return 0.0;
  }
  let filmArea = 4.0 * camTanHalfFov(camera) * camTanHalfFov(camera) * camAspect(camera);
  return 1.0 / (filmArea * cosine * cosine * cosine);
}

fn bdptProjectToCamera(camera: Camera, position: vec3f, normal: vec3f) -> BdptCameraConnection {
  var connection: BdptCameraConnection;
  let displacement = position - camera.pos.xyz;
  let depth = dot(camera.forward.xyz, displacement);
  if (depth <= 0.0) {
    return connection;
  }
  let ndc = vec2f(dot(camera.right.xyz, displacement) / camAspect(camera), dot(camera.up.xyz, displacement))
    / (depth * camTanHalfFov(camera));
  let uv = ndc * vec2f(0.5, -0.5) + 0.5;
  if (any(uv < vec2f(0.0)) || any(uv >= vec2f(1.0))) {
    return connection;
  }
  let direction = normalize(displacement);
  if (dot(normal, -direction) <= 0.0) {
    return connection;
  }
  connection.film = uv * vec2f(uni.resolution);
  connection.pixel = vec2u(connection.film);
  connection.pdfArea = bdptPdfToArea(bdptCameraPdfW(camera, direction), camera.pos.xyz, position, normal)
    * f32(uni.resolution.x * uni.resolution.y);
  connection.valid = connection.pdfArea > 0.0;
  return connection;
}

fn bdptCameraVisible(camera: Camera, position: vec3f) -> bool {
  let displacement = position - camera.pos.xyz;
  let distance = length(displacement);
  if (distance <= SURFACE_EPS) {
    return false;
  }
  let hit = traceScenePrimary(camera.pos.xyz, displacement / distance);
  return hit.hit && abs(hit.t - distance) <= 2.0 * SURFACE_EPS;
}

fn bdptConnectCamera(camera: Camera, vertex: ptr<function, BdptVertex>, lightIsEmitter: bool) -> vec3f {
  if ((*vertex).surface.materialIndex > 0u) {
    return vec3f(0.0);
  }
  let connection = bdptProjectToCamera(camera, (*vertex).surface.pos, (*vertex).surface.normal);
  if (!connection.valid || !bdptCameraVisible(camera, (*vertex).surface.pos)) {
    return vec3f(0.0);
  }
  let bsdf = select((*vertex).surface.albedo * INV_PI, vec3f(1.0), lightIsEmitter);
  return (*vertex).throughput * bsdf * connection.pdfArea;
}

struct BdptMisVertex {
  position: vec3f,
  normal: vec3f,
  delta: bool,
}

struct BdptMisPath {
  vertices: array<BdptMisVertex, BDPT_MAX_VERTICES>,
  count: u32,
  emitterPdfArea: f32,
}

struct BdptWorkspace {
  cameraPath: BdptSubpath,
  lightPath: BdptSubpath,
  misPath: BdptMisPath,
}

fn bdptEmitterPdfArea(quadIndex: u32) -> f32 {
  for (var index = 0u; index < uni.lightCount; index++) {
    if (lights[index].quadIndex == quadIndex) {
      return lights[index].selectPdf / quads[quadIndex].origin.w;
    }
  }
  return 0.0;
}

fn bdptMisVertexFromSurface(surface: HitInfo) -> BdptMisVertex {
  return BdptMisVertex(surface.pos, surface.normal, surface.materialIndex > 0u);
}

fn bdptBuildMisPath(camera: Camera, cameraVertices: u32, lightVertices: u32, workspace: ptr<function, BdptWorkspace>) {
  let cameraPath = &(*workspace).cameraPath;
  let lightPath = &(*workspace).lightPath;
  let path = &(*workspace).misPath;
  (*path).count = 0u;
  (*path).emitterPdfArea = 0.0;
  let count = cameraVertices + lightVertices;
  if (cameraVertices < 1u || count < 2u || count > BDPT_MAX_VERTICES
    || cameraVertices - 1u > (*cameraPath).count || lightVertices > (*lightPath).count) {
    return;
  }
  (*path).count = count;
  (*path).vertices[0] = BdptMisVertex(camera.pos.xyz, camera.forward.xyz, false);
  for (var index = 1u; index < cameraVertices; index++) {
    (*path).vertices[index] = bdptMisVertexFromSurface((*cameraPath).vertices[index - 1u].surface);
  }
  for (var index = 0u; index < lightVertices; index++) {
    (*path).vertices[cameraVertices + index] = bdptMisVertexFromSurface((*lightPath).vertices[lightVertices - index - 1u].surface);
  }
  if (lightVertices > 0u) {
    (*path).emitterPdfArea = (*lightPath).emitterPdfArea;
  } else {
    let emitter = (*cameraPath).vertices[cameraVertices - 2u].surface;
    if (emitter.materialIndex > 0u || maxComponent(emitter.emission) <= 0.0 || !emitter.frontFace) {
      (*path).count = 0u;
      return;
    }
    (*path).emitterPdfArea = bdptEmitterPdfArea(emitter.quadIndex);
    (*path).vertices[count - 1u].normal = quads[emitter.quadIndex].normal.xyz;
  }
}

fn bdptMisEdgeFactor(camera: Camera, path: ptr<function, BdptMisPath>, source: u32, destination: u32) -> f32 {
  let sourceVertex = (*path).vertices[source];
  let destinationVertex = (*path).vertices[destination];
  if (sourceVertex.delta) {
    return 1.0;
  }
  let difference = destinationVertex.position - sourceVertex.position;
  if (dot(difference, difference) <= 0.0) {
    return 0.0;
  }
  let direction = normalize(difference);
  var pdfW = max(0.0, dot(sourceVertex.normal, direction)) * INV_PI;
  if (source == 0u) {
    pdfW = bdptCameraPdfW(camera, direction) * f32(uni.resolution.x * uni.resolution.y);
  }
  return bdptPdfToArea(pdfW, sourceVertex.position, destinationVertex.position, destinationVertex.normal);
}

fn bdptTechniqueWeight(camera: Camera, path: ptr<function, BdptMisPath>, selectedCameraVertices: u32, lightSubpathCount: u32) -> f32 {
  let count = (*path).count;
  if (count < 2u || selectedCameraVertices < 1u || selectedCameraVertices > count) {
    return 0.0;
  }
  var reverse: array<f32, BDPT_MAX_VERTICES>;
  var reverseZeros: array<u32, BDPT_MAX_VERTICES>;
  reverse[count - 1u] = log(max((*path).emitterPdfArea, 1e-38));
  reverseZeros[count - 1u] = select(1u, 0u, (*path).emitterPdfArea > 0.0);
  for (var end = count - 1u; end > 1u; end--) {
    let index = end - 1u;
    let factor = bdptMisEdgeFactor(camera, path, index + 1u, index);
    reverse[index] = reverse[index + 1u] + log(max(factor, 1e-38));
    reverseZeros[index] = reverseZeros[index + 1u] + select(1u, 0u, factor > 0.0);
  }
  var sum: BdptMisSum;
  var selectedScore = 0.0;
  var selectedCount = 0u;
  var selectedSupported = false;
  var forward = 0.0;
  var forwardZeros = 0u;
  for (var t = 1u; t <= count; t++) {
    if (t > 1u) {
      let factor = bdptMisEdgeFactor(camera, path, t - 2u, t - 1u);
      forward += log(max(factor, 1e-38));
      forwardZeros += select(1u, 0u, factor > 0.0);
    }
    var score = forward;
    var supported = forwardZeros == 0u;
    if (t < count) {
      score += reverse[t];
      supported = supported && reverseZeros[t] == 0u
        && !(*path).vertices[t - 1u].delta && !(*path).vertices[t].delta;
    }
    let samples = select(1u, lightSubpathCount, t == 1u);
    bdptAccumulateMis(&sum, score, samples, supported);
    if (t == selectedCameraVertices) {
      selectedScore = score;
      selectedCount = samples;
      selectedSupported = supported;
    }
  }
  return bdptMisWeight(sum, selectedScore, selectedCount, selectedSupported);
}

struct BdptCandidate {
  estimator: vec3f,
  misWeight: f32,
  pixel: vec2u,
}

fn bdptVertexLimit() -> u32 {
  return min(BDPT_MAX_VERTICES, uni.maxBounces + 3u + max(4u, uni.glassShapeCount * 4u));
}

fn bdptPathWithinBudget(path: ptr<function, BdptMisPath>) -> bool {
  if ((*path).count < 2u || (*path).count > bdptVertexLimit()) {
    return false;
  }
  var diffuse = 0u;
  for (var index = 1u; index + 1u < (*path).count; index++) {
    diffuse += select(1u, 0u, (*path).vertices[index].delta);
    if (diffuse > uni.maxBounces + 1u
      || (diffuse == uni.maxBounces + 1u && index + 2u < (*path).count)) {
      return false;
    }
  }
  return true;
}

fn bdptEvaluateCandidate(camera: Camera, cameraVertices: u32, lightVertices: u32, pixel: vec2u, lightSubpathCount: u32, workspace: ptr<function, BdptWorkspace>) -> BdptCandidate {
  let cameraPath = &(*workspace).cameraPath;
  let lightPath = &(*workspace).lightPath;
  let path = &(*workspace).misPath;
  var candidate: BdptCandidate;
  candidate.pixel = pixel;
  bdptBuildMisPath(camera, cameraVertices, lightVertices, workspace);
  if (!bdptPathWithinBudget(path)) {
    return candidate;
  }
  if ((uni.flags & FLAG_BDPT) != 0u && (*path).count > 2u) {
    let direct = (*path).count == 3u && !(*path).vertices[1].delta;
    if ((direct && (uni.flags & FLAG_DI_ENABLED) == 0u) || (!direct && (uni.flags & FLAG_GI_ENABLED) == 0u)) {
      return candidate;
    }
  }
  if (lightVertices == 0u) {
    let vertex = &(*cameraPath).vertices[cameraVertices - 2u];
    candidate.estimator = (*vertex).throughput * (*vertex).surface.emission;
  } else if (cameraVertices == 1u) {
    let vertex = &(*lightPath).vertices[lightVertices - 1u];
    let projected = bdptProjectToCamera(camera, (*vertex).surface.pos, (*vertex).surface.normal);
    if (!projected.valid) {
      return candidate;
    }
    candidate.pixel = projected.pixel;
    candidate.estimator = bdptConnectCamera(camera, vertex, lightVertices == 1u);
  } else {
    candidate.estimator = bdptConnectSurfaces(&(*cameraPath).vertices[cameraVertices - 2u], &(*lightPath).vertices[lightVertices - 1u], lightVertices == 1u);
  }
  if (maxComponent(candidate.estimator) > 0.0) {
    candidate.misWeight = bdptTechniqueWeight(camera, path, cameraVertices, lightSubpathCount);
  }
  return candidate;
}

struct BdptReplayCoordinates {
  filmOffset: vec2f,
  overrideFilm: u32,
  cameraSurface: u32,
}

struct BdptReplaySample {
  techniqueSeeds: vec4u,
  coordinates: BdptReplayCoordinates,
  cameraReconnection: vec4f,
}

struct BdptReplayEvaluation {
  candidate: BdptCandidate,
  endpoint: HitInfo,
  predecessor: HitInfo,
  lightPdfArea: f32,
  cameraPdfArea: f32,
  film: vec2f,
  caustic: bool,
}

struct BdptShift {
  sample: BdptReplaySample,
  evaluation: BdptReplayEvaluation,
  jacobian: f32,
}

fn bdptFilmNdc(film: vec2f) -> vec2f {
  return film / vec2f(uni.resolution) * vec2f(2.0, -2.0) + vec2f(-1.0, 1.0);
}

fn bdptReplayPath(sample: BdptReplaySample, camera: Camera, pixel: vec2u, lightSubpathCount: u32, workspace: ptr<function, BdptWorkspace>, reuseLightSubpath: bool) -> BdptReplayEvaluation {
  var evaluation: BdptReplayEvaluation;
  let s = sample.techniqueSeeds.x;
  let t = sample.techniqueSeeds.y;
  if (t < 1u || s + t < 2u || s + t > BDPT_MAX_VERTICES) {
    return evaluation;
  }
  let cameraPath = &(*workspace).cameraPath;
  let lightPath = &(*workspace).lightPath;
  (*cameraPath).count = 0u;
  if (!reuseLightSubpath) {
    bdptBuildLightSubpath(sample.techniqueSeeds.w, s, lightPath);
  }
  if (t > 1u) {
    gRngState = sample.techniqueSeeds.z;
    let jitter = vec2f(bdptRandom(), bdptRandom());
    let pathSeed = gRngState;
    bdptBuildCameraReplay(camera, bdptFilmNdc(vec2f(pixel) + jitter), pathSeed, t - 1u, sample.cameraReconnection, sample.coordinates.cameraSurface, cameraPath);
  } else if (sample.coordinates.overrideFilm != 0u) {
    let ray = primaryRayDir(camera, bdptFilmNdc(vec2f(pixel) + sample.coordinates.filmOffset));
    let endpoint = traceScenePrimary(camera.pos.xyz, ray);
    if (!endpoint.hit || endpoint.materialIndex > 0u || (*lightPath).count < max(1u, s - 1u)) {
      return evaluation;
    }
    if (s == 1u) {
      if (endpoint.quadIndex != (*lightPath).vertices[0].surface.quadIndex || !endpoint.frontFace) {
        return evaluation;
      }
      (*lightPath).vertices[0].surface = endpoint;
    } else {
      let previous = (*lightPath).vertices[s - 2u];
      let difference = endpoint.pos - previous.surface.pos;
      if (previous.surface.materialIndex > 0u || dot(difference, difference) <= 0.0
        || dot(previous.surface.normal, difference) <= 0.0 || dot(endpoint.normal, -difference) <= 0.0
        || !mutuallyVisible(previous.surface.pos, previous.surface.normal, endpoint.pos)) {
        return evaluation;
      }
      var throughput = previous.throughput * previous.surface.albedo;
      if (s == 2u) {
        throughput = previous.throughput * PI;
      }
      (*lightPath).vertices[s - 1u] = BdptVertex(endpoint, normalize(difference), throughput, 0.0, 0.0, false);
      (*lightPath).count = s;
    }
  }
  evaluation.candidate = bdptEvaluateCandidate(camera, t, s, pixel, lightSubpathCount, workspace);
  if (maxComponent(evaluation.candidate.estimator) <= 0.0 || evaluation.candidate.misWeight <= 0.0) {
    return evaluation;
  }
  if (t == 1u) {
    evaluation.endpoint = (*lightPath).vertices[s - 1u].surface;
    let projection = bdptProjectToCamera(camera, evaluation.endpoint.pos, evaluation.endpoint.normal);
    evaluation.cameraPdfArea = projection.pdfArea;
    evaluation.film = projection.film;
    evaluation.lightPdfArea = (*lightPath).emitterPdfArea;
    if (s > 1u) {
      evaluation.predecessor = (*lightPath).vertices[s - 2u].surface;
      evaluation.caustic = evaluation.predecessor.materialIndex > 0u;
      evaluation.lightPdfArea = 0.0;
      if (!evaluation.caustic) {
        let direction = normalize(evaluation.endpoint.pos - evaluation.predecessor.pos);
        let pdfW = max(0.0, dot(evaluation.predecessor.normal, direction)) * INV_PI;
        evaluation.lightPdfArea = bdptPdfToArea(pdfW, evaluation.predecessor.pos, evaluation.endpoint.pos, evaluation.endpoint.normal);
      }
    }
  }
  return evaluation;
}

fn bdptReplay(sample: BdptReplaySample, camera: Camera, pixel: vec2u, lightSubpathCount: u32, workspace: ptr<function, BdptWorkspace>) -> BdptReplayEvaluation {
  return bdptReplayPath(sample, camera, pixel, lightSubpathCount, workspace, false);
}

struct BdptShiftSource {
  sample: BdptReplaySample,
  evaluation: BdptReplayEvaluation,
  connection: u32,
  pdf: f32,
}

fn bdptPrepareShift(sample: BdptReplaySample, camera: Camera, pixel: vec2u, lightSubpathCount: u32, workspace: ptr<function, BdptWorkspace>) -> BdptShiftSource {
  var source: BdptShiftSource;
  source.sample = sample;
  source.evaluation = bdptReplay(sample, camera, pixel, lightSubpathCount, workspace);
  if (sample.techniqueSeeds.y > 1u && maxComponent(source.evaluation.candidate.estimator) > 0.0) {
    source.connection = bdptCameraReconnection(&(*workspace).cameraPath);
    source.pdf = bdptCameraConnectionPdf(&(*workspace).cameraPath, source.connection);
    if (source.connection > 0u) {
      let surface = (*workspace).cameraPath.vertices[source.connection - 1u].surface;
      source.sample.cameraReconnection = vec4f(surface.pos, f32(source.connection));
      source.sample.coordinates.cameraSurface = surface.quadIndex * 2u + select(0u, 1u, surface.frontFace);
    }
  }
  return source;
}

fn bdptApplyPreparedShift(prepared: BdptShiftSource, sourceCamera: Camera, destinationCamera: Camera, sourcePixel: vec2u, destinationPixel: vec2u, lightSubpathCount: u32, workspace: ptr<function, BdptWorkspace>, reuseLightSubpath: bool) -> BdptShift {
  let sample = prepared.sample;
  var shifted: BdptShift;
  shifted.sample = sample;
  if (sample.techniqueSeeds.y > 1u) {
    if (maxComponent(prepared.evaluation.candidate.estimator) <= 0.0) { return shifted; }
    let connection = prepared.connection;
    let sourcePdf = prepared.pdf;
    shifted.evaluation = bdptReplayPath(shifted.sample, destinationCamera, destinationPixel, lightSubpathCount, workspace, reuseLightSubpath);
    if (maxComponent(shifted.evaluation.candidate.estimator) <= 0.0
      || bdptCameraReconnection(&(*workspace).cameraPath) != connection) { return shifted; }
    if (connection == 0u) {
      shifted.jacobian = 1.0;
    } else if (sourcePdf > 0.0) {
      shifted.jacobian = bdptCameraConnectionPdf(&(*workspace).cameraPath, connection) / sourcePdf;
    }
    return shifted;
  }
  let source = prepared.evaluation;
  if (source.cameraPdfArea <= 0.0 || any(source.candidate.pixel != sourcePixel)) {
    return shifted;
  }
  if (all(sourcePixel == destinationPixel) && all(sourceCamera.pos == destinationCamera.pos)
    && all(sourceCamera.right == destinationCamera.right) && all(sourceCamera.up == destinationCamera.up)
    && all(sourceCamera.forward == destinationCamera.forward)) {
    shifted.evaluation = source;
    shifted.jacobian = 1.0;
    return shifted;
  }
  if (source.caustic || source.lightPdfArea <= 0.0) {
    return shifted;
  }
  shifted.sample.coordinates = BdptReplayCoordinates(fract(source.film), 1u, 0u);
  shifted.evaluation = bdptReplayPath(shifted.sample, destinationCamera, destinationPixel, lightSubpathCount, workspace, reuseLightSubpath);
  if (shifted.evaluation.cameraPdfArea > 0.0) {
    // The estimator includes proposal PDFs; convert the endpoint shift to primary-sample measure.
    shifted.jacobian = (shifted.evaluation.lightPdfArea / source.lightPdfArea)
      * (source.cameraPdfArea / shifted.evaluation.cameraPdfArea);
  }
  return shifted;
}

fn bdptApplyShift(prepared: BdptShiftSource, sourceCamera: Camera, destinationCamera: Camera, sourcePixel: vec2u, destinationPixel: vec2u, lightSubpathCount: u32, workspace: ptr<function, BdptWorkspace>) -> BdptShift {
  return bdptApplyPreparedShift(prepared, sourceCamera, destinationCamera, sourcePixel, destinationPixel, lightSubpathCount, workspace, false);
}

fn bdptShiftBetweenCameras(sample: BdptReplaySample, sourceCamera: Camera, destinationCamera: Camera, sourcePixel: vec2u, destinationPixel: vec2u, lightSubpathCount: u32, workspace: ptr<function, BdptWorkspace>) -> BdptShift {
  let prepared = bdptPrepareShift(sample, sourceCamera, sourcePixel, lightSubpathCount, workspace);
  // Immediate preparation keeps this sample's light prefix in the workspace.
  return bdptApplyPreparedShift(prepared, sourceCamera, destinationCamera, sourcePixel, destinationPixel, lightSubpathCount, workspace, true);
}

fn bdptShiftReplay(sample: BdptReplaySample, camera: Camera, sourcePixel: vec2u, destinationPixel: vec2u, lightSubpathCount: u32, workspace: ptr<function, BdptWorkspace>) -> BdptShift {
  return bdptShiftBetweenCameras(sample, camera, camera, sourcePixel, destinationPixel, lightSubpathCount, workspace);
}

fn bdptShiftCaustic(sample: BdptReplaySample, destinationCamera: Camera, lightSubpathCount: u32, workspace: ptr<function, BdptWorkspace>) -> BdptShift {
  var shifted: BdptShift;
  shifted.sample = sample;
  if (sample.techniqueSeeds.y != 1u || sample.coordinates.overrideFilm != 0u) { return shifted; }
  shifted.evaluation = bdptReplay(sample, destinationCamera, vec2u(0u), lightSubpathCount, workspace);
  if (shifted.evaluation.caustic && shifted.evaluation.cameraPdfArea > 0.0) {
    shifted.jacobian = 1.0;
  }
  return shifted;
}

struct BdptReplayReservoir {
  path: BdptPathReservoir,
  coordinates: BdptReplayCoordinates,
  cameraReconnection: vec4f,
}

fn bdptEmptyReplayReservoir(confidence: f32) -> BdptReplayReservoir {
  return BdptReplayReservoir(bdptEmptyReservoir(confidence), BdptReplayCoordinates(vec2f(0.0), 0u, 0u), vec4f(0.0));
}

fn bdptReservoirSample(reservoir: BdptReplayReservoir) -> BdptReplaySample {
  return BdptReplaySample(reservoir.path.sample.techniqueSeeds, reservoir.coordinates, reservoir.cameraReconnection);
}

fn bdptUpdateReplayReservoir(
  reservoir: ptr<function, BdptReplayReservoir>,
  sample: BdptReplaySample,
  candidate: BdptCandidate,
  contributionWeight: f32,
  resamplingWeight: f32,
  jacobian: f32,
  random: f32,
) {
  let pathSample = BdptPathSample(sample.techniqueSeeds, vec4f(candidate.estimator, candidate.misWeight));
  if (bdptUpdateReservoir(&(*reservoir).path, pathSample, contributionWeight, resamplingWeight, jacobian, random)) {
    (*reservoir).coordinates = sample.coordinates;
    (*reservoir).cameraReconnection = sample.cameraReconnection;
  }
}

fn bdptMergeSameDomain(
  output: ptr<function, BdptReplayReservoir>,
  input: BdptReplayReservoir,
  totalConfidence: f32,
  random: f32,
) {
  if (totalConfidence <= 0.0) {
    return;
  }
  if (bdptUpdateReservoir(&(*output).path, input.path.sample, input.path.contributionWeight,
    input.path.confidence / totalConfidence, 1.0, random)) {
    (*output).coordinates = input.coordinates;
    (*output).cameraReconnection = input.cameraReconnection;
  }
}

fn bdptTemporalReservoir(
  current: BdptReplayReservoir,
  previous: BdptReplayReservoir,
  maximumPreviousConfidence: f32,
  random: f32,
) -> BdptReplayReservoir {
  var history = previous;
  history.path.confidence = min(history.path.confidence, max(0.0, maximumPreviousConfidence));
  let confidence = current.path.confidence + history.path.confidence;
  var output = bdptEmptyReplayReservoir(confidence);
  bdptMergeSameDomain(&output, current, confidence, 0.0);
  bdptMergeSameDomain(&output, history, confidence, random);
  bdptFinalizeReservoir(&output.path);
  return output;
}

struct BdptReservoirPair {
  normal: BdptReplayReservoir,
  caustic: BdptReplayReservoir,
}

struct BdptLightNode {
  reservoir: BdptReplayReservoir,
  nextPixel: vec4u,
}

fn bdptStreamInitial(reservoir: ptr<function, BdptReplayReservoir>, seeds: vec4u, candidate: BdptCandidate) -> bool {
  let sample = BdptPathSample(seeds, vec4f(candidate.estimator, candidate.misWeight));
  return bdptUpdateReservoir(&(*reservoir).path, sample,
    bdptInitialWeight(seeds.y, uni.resolution.x * uni.resolution.y), 1.0, 1.0, bdptRandom());
}

struct BdptTemporalNode {
  reservoir: BdptReplayReservoir,
  sourceTarget: f32,
  sourceConfidence: f32,
  jacobian: f32,
  scorePadding: f32,
  head: atomic<u32>,
  next: u32,
  padding: vec2u,
}

fn bdptCameraUnchanged() -> bool {
  return all(uni.cam.pos == uni.prevCam.pos) && all(uni.cam.right == uni.prevCam.right)
    && all(uni.cam.up == uni.prevCam.up) && all(uni.cam.forward == uni.prevCam.forward);
}

fn bdptTemporalConfidence(value: f32) -> f32 {
  return min(value, f32(max(1u, uni.maxHistory) - 1u));
}

fn bdptReplayTarget(evaluation: BdptReplayEvaluation, sample: BdptReplaySample) -> f32 {
  return bdptTarget(BdptPathSample(sample.techniqueSeeds,
    vec4f(evaluation.candidate.estimator, evaluation.candidate.misWeight)));
}

@group(1) @binding(0) var<storage, read> temporalReservoirs: array<BdptReservoirPair>;
@group(1) @binding(1) var<storage, read_write> finalReservoirs: array<BdptReservoirPair>;

@compute @workgroup_size(BDPT_WORKGROUP_SIZE, BDPT_WORKGROUP_SIZE)
fn main(@builtin(global_invocation_id) gid: vec3u) {
  if (any(gid.xy >= bdptDispatchRegion.extent)) { return; }
  let pixel = gid.xy + bdptDispatchRegion.origin;
  if (any(pixel >= uni.resolution)) { return; }
  let index = pixel.y * uni.resolution.x + pixel.x;
  let center = temporalReservoirs[index];
  finalReservoirs[index] = center;
  if ((uni.flags & FLAG_GI_SPATIAL) == 0u || uni.spatialSamples == 0u) { return; }
  let surface = traceScenePrimary(uni.cam.pos.xyz, primaryRayDir(uni.cam, pixelNdc(pixel)));
  if (!surface.hit || surface.materialIndex > 0u) { return; }
  rngInit(pixel, uni.frame, 47u);
  var domains: array<vec2u, 33>;
  domains[0] = pixel;
  var lastNeighbor = pixel;
  var count = 1u;
  let radius = spatialPixelRadius(uni.cam, surfaceDepth(uni.cam, surface.pos));
  for (var attempt = 0u; attempt < min(32u, uni.spatialSamples); attempt++) {
    let offset = spatialOffset(radius, bdptRandom() * 2.0 * PI, bdptRandom());
    let coordinate = vec2i(pixel) + offset;
    if (any(coordinate < vec2i(0)) || any(coordinate >= vec2i(uni.resolution))) { continue; }
    let neighbor = vec2u(coordinate);
    if (all(lastNeighbor == neighbor)) { continue; }
    let hit = traceScenePrimary(uni.cam.pos.xyz, primaryRayDir(uni.cam, pixelNdc(neighbor)));
    let difference = hit.pos - surface.pos;
    let normalDistance = dot(difference, surface.normal);
    if (!hit.hit || hit.materialIndex > 0u || dot(hit.normal, surface.normal) < 0.9
      || abs(normalDistance) > 0.05 || length(difference - normalDistance * surface.normal) > uni.spatialRadius) { continue; }
    domains[count] = neighbor;
    lastNeighbor = neighbor;
    count++;
  }
  if (count == 1u) { return; }
  var selectionState = gRngState;
  var workspace: BdptWorkspace;
  var confidence = center.normal.path.confidence;
  var output = bdptEmptyReplayReservoir(confidence);
  let lightCount = uni.resolution.x * uni.resolution.y;
  let centerConfidence = confidence / f32(min(32u, uni.spatialSamples));
  let centerTarget = center.normal.path.targetDensity;
  var centerWeight = 1.0;
  var preparedCenter: BdptShiftSource;
  if (centerTarget > 0.0) {
    preparedCenter = bdptPrepareShift(bdptReservoirSample(center.normal), uni.cam, pixel, lightCount, &workspace);
  }
  for (var sourceIndex = 1u; sourceIndex < count; sourceIndex++) {
    let sourcePixel = domains[sourceIndex];
    let source = temporalReservoirs[sourcePixel.y * uni.resolution.x + sourcePixel.x].normal;
    confidence += source.path.confidence;
    var centerPairWeight = 1.0;
    if (centerTarget > 0.0 && source.path.confidence > 0.0) {
      let inverse = bdptApplyShift(preparedCenter, uni.cam, uni.cam, pixel, sourcePixel, lightCount, &workspace);
      let inverseSample = BdptPathSample(inverse.sample.techniqueSeeds,
        vec4f(inverse.evaluation.candidate.estimator, inverse.evaluation.candidate.misWeight));
      let other = bdptBalanceNumerator(source.path.confidence, bdptTarget(inverseSample), inverse.jacobian);
      centerPairWeight = bdptPairwiseWeight(centerConfidence * centerTarget, other);
    }
    centerWeight += centerPairWeight;
    if (source.path.targetDensity <= 0.0 || source.path.confidence <= 0.0) { continue; }
    let shifted = bdptShiftReplay(bdptReservoirSample(source), uni.cam, sourcePixel, pixel, lightCount, &workspace);
    if (shifted.jacobian <= 0.0) { continue; }
    let shiftedSample = BdptPathSample(shifted.sample.techniqueSeeds,
      vec4f(shifted.evaluation.candidate.estimator, shifted.evaluation.candidate.misWeight));
    let own = bdptBalanceNumerator(source.path.confidence, source.path.targetDensity, 1.0 / shifted.jacobian);
    let weight = bdptPairwiseWeight(own, centerConfidence * bdptTarget(shiftedSample)) / f32(count);
    gRngState = selectionState;
    let random = bdptRandom();
    selectionState = gRngState;
    bdptUpdateReplayReservoir(&output, shifted.sample, shifted.evaluation.candidate,
      source.path.contributionWeight, weight, shifted.jacobian, random);
  }
  gRngState = selectionState;
  let selectedCenter = bdptUpdateReservoir(&output.path, center.normal.path.sample,
    center.normal.path.contributionWeight, centerWeight / f32(count), 1.0, bdptRandom());
  if (selectedCenter) { output.coordinates = center.normal.coordinates; output.cameraReconnection = center.normal.cameraReconnection; }
  output.path.confidence = min(confidence, f32(max(1u, uni.maxHistory)));
  bdptFinalizeReservoir(&output.path);
  finalReservoirs[index] = BdptReservoirPair(output, center.caustic);
}
