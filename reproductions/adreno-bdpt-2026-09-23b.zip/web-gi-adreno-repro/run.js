const button = document.querySelector('#run');
const output = document.querySelector('#report');
button.onclick = async () => {
  button.disabled = true;
  const report = { outcome: 'RUNNING', stage: 'source', userAgent: navigator.userAgent, events: [] };
  window.result = report;
  const started = performance.now();
  const log = message => {
    report.events.push({ ms: Math.round(performance.now() - started), message });
    output.textContent = JSON.stringify(report, null, 2);
  };
  let device, timer;
  let active = true;
  try {
    if (!isSecureContext || !navigator.gpu) throw Error('WebGPU unavailable; use localhost or HTTPS');
    report.variant = document.querySelector('#variant').value;
    const response = await fetch(report.variant + '.wgsl');
    if (!response.ok) throw Error('Shader fetch failed: ' + response.status);
    const code = await response.text();
    const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(code));
    report.sha256 = [...new Uint8Array(digest)].map(v => v.toString(16).padStart(2, '0')).join('');
    report.stage = 'adapter';
    const adapter = await navigator.gpu.requestAdapter({ powerPreference: 'high-performance' });
    if (!adapter) { report.outcome = 'NO_ADAPTER'; throw Error('No WebGPU adapter'); }
    const {vendor, architecture, device: model, description} = adapter.info;
    report.adapter = {vendor, architecture, model, description};
    report.stage = 'device';
    device = await adapter.requestDevice();
    device.addEventListener('uncapturederror', e => log(String(e.error)));
    log('Device ready');
    await Promise.race([
      device.lost.then(info => { throw Error(`Device lost (${info.reason}): ${info.message}`); }),
      new Promise((_, reject) => { timer = setTimeout(() => { report.outcome = 'TIMEOUT'; reject(Error('30 second compilation timeout')); }, 30000); }),
      (async () => {
        report.stage = 'shader';
        const module = device.createShaderModule({ code });
        const info = await module.getCompilationInfo();
        if (!active) return;
        const errors = info.messages.filter(m => m.type === 'error');
        if (errors.length) throw Error(errors.map(m => m.message).join('\n'));
        report.stage = 'pipeline';
        log('Shader validated; creating compute pipeline');
        const bindings = [
          Array.from({length: 5}, (_, binding) => ({binding, buffer: {type: binding === 0 ? 'uniform' : 'read-only-storage'}})),
          [{binding: 0, buffer: {type: 'read-only-storage'}}, {binding: 1, buffer: {type: 'storage'}}],
          [{binding: 0, buffer: {type: 'uniform', hasDynamicOffset: true}}],
        ];
        await device.createComputePipelineAsync({
          layout: device.createPipelineLayout({bindGroupLayouts: bindings.map(entries => device.createBindGroupLayout({entries: entries.map(entry => ({...entry, visibility: GPUShaderStage.COMPUTE}))}))}),
          compute: {module, entryPoint: 'main', constants: {BDPT_WORKGROUP_SIZE: 1}},
        });
      })(),
    ]);
    report.outcome = 'PASS';
    log('Compilation completed; no dispatch');
  } catch (error) {
    if (report.outcome === 'RUNNING') report.outcome = 'FAIL';
    log(String(error));
  } finally {
    active = false;
    clearTimeout(timer);
    device?.destroy();
  }
};
