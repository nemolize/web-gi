# Intermittent Adreno compute pipeline compilation crash

Compiling the BDPT spatial-reuse compute shader from `nemolize/web-gi` crashes
the Adreno 830 driver inside `vkCreateComputePipelines`, intermittently. This
package reproduces it in a standalone page with no build step or dependencies:
it validates a captured WGSL and calls `createComputePipelineAsync`, creating no
buffers and submitting no GPU work.

**The crash is probabilistic per compile, and the same WGSL text gives different
outcomes on different runs.** Read the protocol section before interpreting any
number here; a small run of passes does not mean a variant is safe.

## Run

1. In this directory, run `python3 -m http.server 8769 --bind 127.0.0.1`.
2. Connect the Android device using ADB (USB or already-paired wireless).
   Run `adb -s DEVICE_SERIAL reverse tcp:8769 tcp:8769`.
3. Open `http://localhost:8769/` in the target browser, choose a variant, press
   **Run once**, and retain the JSON report.
4. Restart the browser between trials (see protocol). If no adapter is
   available, restart and label that trial separately from a compilation
   failure.
5. Remove the temporary forwarding when finished:
   `adb -s DEVICE_SERIAL reverse --remove tcp:8769`.

Keep the browser foreground while comparing trials. Serving via a LAN HTTP
address is not equivalent to localhost's secure context. No diagnostic browser
flags are required. `file://` is not supported by this fetch-based harness.
The page runs only on a button press and never uploads results.

The 30-second timeout covers shader and pipeline compilation after device
creation; it does not cover source loading or adapter/device acquisition.

### Capturing the native crash

The page only reports device loss. The driver crash is in the Android crash
buffer, so capture it alongside each trial:

```sh
start=$(adb -s DEVICE_SERIAL shell "date '+%m-%d %H:%M:%S.000'")
# press Run once, wait for the report, then:
adb -s DEVICE_SERIAL logcat -d -b crash -v threadtime -T "$start" \
  | grep -E 'Cmdline: |Fatal signal|signal 11|#00 pc|vkCreateComputePipelines'
```

Taking `start` from the device clock rather than the host clock is what makes
the excerpt line up with the trial. The `crash` arrays in `validation.jsonl`
are the output of exactly this filter.

## Measurement protocol — why it decides the answer

Two effects make a naive trial loop report far fewer failures than occur.

**A successful compile is cached.** Repeating the same WGSL in the same browser
after a pass can hit that cache instead of compiling again. Failures cache
nothing, so repetition inflates passes and never inflates failures. Every
"variant X is safe" claim is vulnerable to this; no failure claim is.

**A crashed GPU process changes the browser's behaviour.** After repeated
crashes Chrome returns `NO_ADAPTER`, and trials immediately following a crash
behave differently from trials in a fresh browser.

So a trial counts here only when **the browser was restarted immediately before
it** and **that exact WGSL text had never been compiled on the device**. A fresh
text is produced by appending one comment line, which changes the cache key
without changing the program:

```sh
printf '\n// cache-key probe 1790091500\n' >> variant-copy.wgsl
```

Every figure below comes from trials meeting both conditions. `validation.jsonl`
records the protocol per row, so trials taken under the weaker protocol are
distinguishable and are excluded from the tables.

## The crash does not depend on the shader alone

`cold-dup-fixed-index-9` (a text that failed) was re-run seven more times in
freshly restarted browsers. Identical text, and no successful blob could be
cached because the first run crashed. It failed once and passed seven times.

Separately, 23 copies of one variant differing only in a trailing comment split
9 failures to 14 passes.

Whatever varies between two compiles of the same program, it is in the browser
or driver process, not in the WGSL.

## Variants and measured failure rates

All variants descend from production `src/gi/shaders/bdpt-spatial.wgsl` at
revision `a5aa13b39828e3cf6e6bd068b379b089880d04ac`, with vertex capacity 10 and
override `BDPT_WORKGROUP_SIZE = 1`. Explicit bind-group layouts, entry point
`main`. See `SHA256SUMS`.

Chrome 153.0.8010.52, Samsung SM-F966Q, Android 16, Adreno 830, 2026-09-23.

| Variant | Failures | Derivation |
| --- | --- | --- |
| `dyn-read-flat` | 8/8 | inverse replay; one dynamic `domains[]` read before the trace call |
| `dup-late-branch` | 8/8 | `two-neighbors`, duplicate branch moved after the trace |
| `dup-fixed-trip` | 8/8 | `two-neighbors`, inner loop fixed at 2 iterations |
| `outer-fixed-trip` | 8/8 | `dyn-read-flat`, outer loop fixed at 32 iterations |
| `two-neighbors` | 5/5 | inverse replay, production neighbor discovery and reservoir output |
| `dup-fixed-index` | 9/23 | `two-neighbors`, `domains[other]` replaced by `domains[0]` |
| `prod-scalar` | 9/39 | production, duplicate check held in a scalar |
| **`prod-full`** | **8/40** | **production spatial pass, unmodified** |
| `loop-no-dup` | 0/10 | `two-neighbors`, duplicate check removed |
| `dyn-read-after-trace` | 0/10 | `dyn-read-flat`, dynamic read moved after the trace |
| `loop-no-trace` | 0/8 | `two-neighbors`, trace removed from the loop |
| `trace-no-loop` | 0/8 | inverse replay, trace once, no discovery loop |
| `dyn-read-scalar` | 0/8 | `dyn-read-flat`, dynamic read replaced by a scalar |

**A 0/N row does not mean the variant is safe.** 0 failures in 8 trials bounds
the rate below roughly 31% at 95% confidence, and below 26% at 10 trials — both
of which contain `prod-full`'s measured 20%. These rows are not distinguishable
from the production shader on this data.

`repro`, `no-discovery` and `control` are the variants from the 2026-09-22
session, retained so sequences 1–13 of `validation.jsonl` stay interpretable.
They were not measured under this protocol.

### What the table does and does not show

Failure rates run continuously from 8/8 down to 0/10 with no boundary. Each
edit moves the rate; none isolates a language construct that is present in the
failing variants and absent from the passing ones. Taken with the same-text
result above, the shape of this is a threshold the compiler crosses, not a
specific construct it mishandles.

Two specific negative results are worth stating because they look like findings
and are not:

- Replacing the dynamic array read with a scalar removes the crash in the
  reduced shape (`dyn-read-flat` 8/8 → `dyn-read-scalar` 0/8) but **not in the
  production shape**: `prod-full` 8/40 against `prod-scalar` 9/39, two-sided
  Fisher exact p = 0.79. It is not a workaround.
- Moving the dynamic read after the trace call (`dyn-read-after-trace`, 0/10)
  likewise only shifts the rate below what 10 trials can resolve.

### Native crash signature

Every failing trial, across both browsers, all dates and all variants,
correlated with SIGSEGV / SEGV_ACCERR in the browser's privileged process, with
top frame `/vendor/lib64/libllvm-qgl.so`, offset `0x5462dc`, BuildId
`cef5d401886c24314fb684ab4dd7e70a`. The stack includes
`qglinternal::vkCreateComputePipelines` in `vulkan.adreno.so`, BuildId
`1267f8e0425e6782225076cf3e39aa61`. The offset and BuildIds are identical for
every variant, including `prod-full`.

This identifies a native compiler-path crash, not its root cause. Generated
SPIR-V was not obtained. Browser/Tint output differences, driver compiler
behaviour, and resource pressure have not been separated.

### Mises

Mises (`site.mises.browser_stable`, CDP Chrome/141.0.7390.108, page UA
Chrome/140.0.0.0) failed 2 of 6 `repro` trials on 2026-09-22 and did not
reproduce at all on 2026-09-23: `repro` passed 4/4, `repro` with a fresh cache
key passed 4/4, `two-neighbors` passed 4/4. Neither day's Mises counts should be
read as a rate.

### 2026-09-22 session

Sequences 1–13 of `validation.jsonl` predate this protocol: repeat trials in one
browser, only `repro` and `control` present. Chrome failed 3 of 3 `repro`
trials, Mises 2 of 6. Those rows are retained as evidence of the crash but their
pass counts are subject to the caching effect described above.

## Harness note

`run.js` stops shader validation and pipeline creation once the race has settled
on a timeout or device loss, so a late response cannot rewrite a finished report
or reach a destroyed device. Sequences 1–12 predate that guard; sequence 13
onward include it. The guard does not touch compilation itself.
