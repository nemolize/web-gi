# Intermittent Adreno compute pipeline compilation crash

Standalone reproduction extracted from `nemolize/web-gi` revision
`a5aa13b39828e3cf6e6bd068b379b089880d04ac`, diagnostic
`bdpt-spatial-inverse-two-direct-output`. No build step or dependencies.
This is an isolated reproduction, not a minimal shader or a rendering fix.

## Run

1. In this directory, run `python3 -m http.server 8769 --bind 127.0.0.1`.
2. Connect the Android device using ADB (USB or already-paired wireless).
   Run `adb -s DEVICE_SERIAL reverse tcp:8769 tcp:8769`.
3. Open `http://localhost:8769/` in the target browser. Choose **Inverse replay
   probe**, press **Run once**, and retain the JSON report.
4. Reload to repeat. Test **No-replay control** separately. Record every trial;
   a single pass does not establish compatibility. If no adapter is available,
   restart the browser and label that trial separately from compilation failure.
5. Remove the temporary forwarding when finished:
   `adb -s DEVICE_SERIAL reverse --remove tcp:8769`.

Keep the browser foreground while comparing trials. Serving via a LAN HTTP
address is not equivalent to localhost's secure context. No diagnostic browser
flags are required. `file://` is not supported by this fetch-based harness.
The page runs only on a button press and never uploads results.

The 30-second timeout covers shader and pipeline compilation after device
creation; it does not cover source loading or adapter/device acquisition.

## What it does

Requests a high-performance adapter and a default device, validates the captured
WGSL, then calls `createComputePipelineAsync`. Uses explicit bind-group layouts,
entry point `main`, and override `BDPT_WORKGROUP_SIZE = 1`, matching the source
diagnostic. WGSL has a vertex capacity of 10. No buffers, bind groups, render
commands, or dispatches are created. The device is destroyed afterward.

Both WGSL files are exact captures, including shared unused code. The control
removes both replay paths and can optimize differently; it is not a proof of
which source construct causes the crash. See `SHA256SUMS` for integrity.

## Observations on 2026-09-22

Device: Samsung SM-F966Q, Android 16, Adreno 830.
Mises package: `site.mises.browser_stable`. Its CDP version reported
Chrome/141.0.7390.108; the page UA reports Chrome/140.0.0.0.

With ordinary browser settings, the standalone inverse probe failed 2/6 trials
and passed 4/6. One failing trial did not remain foreground at every sample;
the other five trials did, including one native crash. The control passed 1/1.
These small counts demonstrate reproduction, not a failure-rate estimate.
Raw page outcomes and filtered native crash evidence are in `validation.jsonl`.

The Mises failures correlated with SIGSEGV / SEGV_ACCERR in the Mises privileged
process, with top frame `/vendor/lib64/libllvm-qgl.so`, offset `0x5462dc`,
BuildId `cef5d401886c24314fb684ab4dd7e70a`. The stack includes
`qglinternal::vkCreateComputePipelines` in `vulkan.adreno.so`, BuildId
`1267f8e0425e6782225076cf3e39aa61`.

This identifies a native compiler-path crash, not its precise root cause.
Generated SPIR-V was not obtained. Browser/Tint output differences, driver
compiler behavior, and resource pressure have not been separated. Browser and
driver caches are uncontrolled in these standalone trials; passing timings
must not be interpreted as fresh compiler performance.

Chrome CDP reported Chrome/153.0.8010.52. On the same standalone page,
the inverse probe failed 3/3 trials, all foreground, with the same native
crash offset and driver BuildIds. Earlier passes in Chrome on the application
diagnostic therefore do not establish a browser-version fix. Identical WGSL
does not establish identical generated SPIR-V or cache state.

After the three Chrome crashes, the first control attempt returned `NO_ADAPTER`
before compilation. After restarting Chrome, the control passed; a later post-review smoke run
also passed (2/2 compilation attempts). All
attempts are retained in the evidence. `environment.json` records selected
ADB properties and CDP version fields collected during this investigation.

The final harness adds a guard against continuing shader validation after a
timeout/device loss. The final JSONL row is a Chrome control smoke run after
that guard (not foreground at every sample, so not a timing comparison); earlier trials used the otherwise identical harness without it.
Synthetic delayed-validation tests cover timeout, device loss, and success.
